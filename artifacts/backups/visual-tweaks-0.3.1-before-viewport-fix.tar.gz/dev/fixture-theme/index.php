<!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head><body <?php body_class(); ?>><?php wp_body_open(); ?>
<main><header><strong>ATELIER / VT</strong><span>Banc d’essai WordPress</span></header><section class="hero" id="hero"><div><span class="eyebrow">Développement visuel</span><h1 data-vt-id="hero-title">Un détail change tout.</h1><p class="intro">Sélectionnez le téléphone, remontez-le de 25 px et enregistrez. Cette page est indépendante de vos sites.</p><a class="cta" href="?second=1">Découvrir l’atelier</a></div><div class="device-wrap"><img data-vt-id="hero-phone" class="hero-phone" src="<?php echo esc_url(get_stylesheet_directory_uri() . '/phone.svg'); ?>" alt="Téléphone de démonstration"></div></section><section class="cards"><article class="card"><h2 id="card-title">Rapide</h2><p>Un sélecteur unique par identifiant.</p></article><article class="card"><h2>Réversible</h2><p>Une cible par hiérarchie courte.</p></article></section><p class="test-links"><a href="?second=1">Autre page (isolation)</a> · <a href="<?php echo esc_url(admin_url()); ?>">Administration</a></p>
<section class="asset-fixtures" aria-label="Assets de démonstration"><h2>Assets de démonstration</h2>
<div class="asset-grid">
<div class="fixture-background" data-vt-id="fixture-background" aria-label="Fond de démonstration" style="background-image:url('<?php echo esc_url(get_stylesheet_directory_uri() . '/phone.svg'); ?>')"><div class="fixture-overlay" data-vt-id="fixture-overlay" aria-label="Voile du fond"></div></div>
<picture><source media="(max-width:767px)" srcset="<?php echo esc_url(get_stylesheet_directory_uri() . '/phone.svg'); ?>"><img data-vt-id="fixture-logo" class="fixture-logo" src="<?php echo esc_url(get_stylesheet_directory_uri() . '/phone.svg'); ?>" alt="Logo Atelier"></picture>
<div class="fixture-covered"><img data-vt-id="fixture-covered-image" src="<?php echo esc_url(get_stylesheet_directory_uri() . '/phone.svg'); ?>" alt="Asset derrière un voile"><div class="fixture-cover" aria-label="Voile transparent"></div></div>
<svg data-vt-id="fixture-icon" aria-label="Icône Atelier" width="120" height="120" viewBox="0 0 120 120"><title>Icône Atelier</title><circle cx="60" cy="60" r="54" fill="currentColor"/><path d="M35 75 L60 30 L85 75 Z" fill="#f8f7f1"/></svg>
</div></section>
<?php if (isset($_GET['vt-test']) && str_starts_with((string) $_GET['vt-test'], 'width-contract')): ?>
<section class="width-fixtures" style="padding:40px;background:#fff">
<?php foreach (['fit-content', 'max-content', 'min-content', 'calc(150px - 22.7px)', 'clamp(120px, 30vw, 170px)', '127.123456px', 'auto', '57%'] as $index => $width): ?>
<div data-vt-id="width-case-<?php echo $index; ?>" style="width:<?php echo esc_attr($width); ?>;height:70px;margin:24px 0;border:1.3px solid #778;padding:3.7px;box-sizing:content-box;background:#eee"><strong>Largeur du thème</strong></div>
<?php endforeach; ?>
<span data-vt-id="width-inline" style="width:fit-content"><strong>Zone en ligne</strong></span>
</section>
<?php endif; ?></main>
<?php wp_footer(); ?></body></html>
