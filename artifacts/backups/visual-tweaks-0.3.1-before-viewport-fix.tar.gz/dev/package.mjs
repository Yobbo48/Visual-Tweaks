import {mkdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
await mkdir('artifacts',{recursive:true});
const result=spawnSync('zip',['-r','-FS','artifacts/visual-tweaks-0.3.1.zip','visual-tweaks'],{encoding:'utf8'});
if(result.status)throw new Error(result.stderr);
console.log('artifacts/visual-tweaks-0.3.1.zip');
