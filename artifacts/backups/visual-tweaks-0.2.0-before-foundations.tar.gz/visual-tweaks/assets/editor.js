import { identify, editable, canEditText } from "./selection.js?ver=0.2.0";
import { History } from "./history.js?ver=0.2.0";
import { effectiveProperties } from "./styles.js?ver=0.2.0";
import { validValue, validHref } from "./validation.js?ver=0.2.0";
import { InlineEditor } from "./inline-editor.js?ver=0.2.0";
import { ContextualToolbar } from "./contextual-toolbar.js?ver=0.2.0";
import {
  discoverFonts,
  discoverColors,
  colorControl,
  toHex,
} from "./appearance-controls.js?ver=0.2.0";
import {
  matrixFor,
  localDelta,
  resizeDimensions,
  visualQuad,
} from "./geometry.js?ver=0.2.0";

const config = window.VisualTweaksConfig;
if (config?.editor) start();
function start() {
  const host = document.createElement("div");
  host.id = "vt-editor-host";
  document.body.append(host);
  const ui = host.attachShadow({ mode: "open" });
  const css = document.createElement("link");
  css.rel = "stylesheet";
  css.href = new URL("./editor.css?ver=0.2.0", import.meta.url).href;
  ui.append(css);
  const shell = document.createElement("div");
  shell.className = "shell";
  shell.innerHTML = `<header><div class="brand"><b>VT</b><span>Visual Tweaks<small>Retouches de cette page</small></span></div><nav aria-label="Aperçu responsive"><button data-mode="desktop"><img alt="" src="${new URL("./icons/device-desktop.svg", import.meta.url)}">Desktop</button><button data-mode="tablet"><img alt="" src="${new URL("./icons/device-tablet.svg", import.meta.url)}">Tablette</button><button data-mode="mobile"><img alt="" src="${new URL("./icons/device-mobile.svg", import.meta.url)}">Mobile</button></nav><span id="state" role="status"></span><button id="undo" title="Cmd/Ctrl + Z">Annuler</button><button id="redo" title="Cmd/Ctrl + Shift + Z">Rétablir</button><button id="save" class="primary">Enregistrer</button><button id="toggle-panel" title="Afficher ou masquer les réglages" aria-expanded="true">Réglages</button><button id="exit">Quitter</button></header><main><div class="stage"><div class="viewport"><iframe title="Page WordPress — aperçu réel"></iframe></div><div class="outline hover"><span></span></div><div class="outline selected"><span></span><button class="drag" title="Glisser pour déplacer" aria-label="Déplacer l’élément"><img alt="" src="${new URL("./icons/arrows-move.svg", import.meta.url)}"></button></div><div id="context-toolbar"></div><div id="handles" hidden></div><div class="gesture-feedback" hidden></div></div><aside><div id="panel"></div><footer><button id="reset-page">Réinitialiser la page</button><button id="export">Exporter le brouillon JSON</button><button id="discard">Revenir à la sauvegarde</button><div id="recovery"></div><p id="message" role="status" aria-live="polite"></p></footer></aside></main>`;
  ui.append(shell);
  const $ = (selector) => ui.querySelector(selector);
  const frame = $("iframe"),
    panel = $("#panel"),
    state = $("#state");
  $("aside").prepend($("#message"));
  let draft = structuredClone(config.elements),
    saved = JSON.stringify(draft),
    revision = config.revision;
  const history = new History(draft);
  let selected = null,
    spec = null,
    mode = "desktop",
    runtime = null,
    busy = false,
    pending = null,
    drag = null;
  let cropMode = false,
    lockRatio = true,
    fonts = [],
    siteColors = [],
    inlineSnapshot = null;
  const colorStorageKey = `visual-tweaks-colors:${location.origin}:${config.editor.userId}`;
  const contextual = new ContextualToolbar($("#context-toolbar"), $(".stage"));
  const inline = new InlineEditor({
    runtime: () => runtime,
    onInput: (text) =>
      modify((item) => {
        item.content ||= {};
        item.content.text = text;
      }),
    onFinish: () => {
      preview();
      flush();
      renderPanel();
      message("Texte modifié. Enregistrez pour le conserver.");
    },
    onCancel: () => {
      draft = inlineSnapshot;
      preview();
      renderPanel();
      message("Édition du texte annulée.");
    },
  });
  $("#toggle-panel").addEventListener("click", () => {
    const hidden = !$("aside").hidden;
    $("aside").hidden = hidden;
    $("#toggle-panel").setAttribute("aria-expanded", String(!hidden));
    if (mode === "desktop")
      frame.style.width = `${Math.max(1100, $(".stage").clientWidth - 48)}px`;
    updateOutline();
  });
  const draftKey = `visual-tweaks:${location.origin}:${config.editor.userId}:${config.page}`;
  let recovered = null;
  try {
    recovered = JSON.parse(localStorage.getItem(draftKey));
  } catch {}
  let recoveryPending = !!(
    recovered &&
    recovered.page === config.page &&
    Array.isArray(recovered.elements) &&
    JSON.stringify(recovered.elements) !== saved
  );
  const message = (text, error = false) => {
    $("#message").textContent = text;
    $("#message").classList.toggle("error", error);
  };
  const dirty = () => JSON.stringify(draft) !== saved;
  function persistDraft() {
    try {
      if (dirty())
        localStorage.setItem(
          draftKey,
          JSON.stringify({
            schemaVersion: 1,
            page: config.page,
            revision,
            elements: draft,
          }),
        );
      else if (!recoveryPending) localStorage.removeItem(draftKey);
    } catch {
      message(
        "Le brouillon local n’a pas pu être conservé. Enregistrez ou exportez avant de fermer.",
        true,
      );
    }
  }
  function status() {
    state.textContent = busy
      ? "Enregistrement…"
      : dirty()
        ? "Modifications non enregistrées"
        : "Enregistré";
    state.classList.toggle("dirty", dirty());
    $("#undo").disabled = !history.canUndo;
    $("#redo").disabled = !history.canRedo;
    $("#save").disabled = busy || !dirty() || !runtime;
    $("#reset-page").disabled = busy;
    persistDraft();
  }
  function flush() {
    if (inline.active) return;
    clearTimeout(pending);
    pending = null;
    history.push(draft);
    status();
  }
  function commit() {
    clearTimeout(pending);
    pending = setTimeout(flush, 350);
  }
  function preview() {
    const issues = runtime?.render(draft) || [];
    if (issues.length)
      message(
        `${issues.length} cible(s) introuvable(s) ou modifiée(s). Aucun override appliqué à ces cibles.`,
        true,
      );
    status();
    updateOutline();
    syncQuick();
  }
  function entry() {
    return draft.find((e) => e.id === spec?.id) || spec;
  }
  function modify(callback) {
    if (!spec) return;
    if (recoveryPending) {
      message(
        "Un brouillon local attend votre décision. Récupérez-le ou utilisez « Revenir à la sauvegarde » avant de retoucher.",
        true,
      );
      return;
    }
    let item = draft.find((e) => e.id === spec.id);
    if (!item) {
      item = structuredClone(spec);
      draft.push(item);
    }
    callback(item);
    preview();
    if (!drag && !inline.active) commit();
  }
  function setProperty(property, value) {
    if (recoveryPending) {
      message(
        "Récupérez le brouillon local ou revenez à la sauvegarde avant de retoucher.",
        true,
      );
      return;
    }
    message("");
    modify((item) => {
      item.changes[mode] ||= {};
      if (value === "") delete item.changes[mode][property];
      else item.changes[mode][property] = value;
    });
  }
  function rectOverlay(box, node) {
    if (!node || !node.isConnected) {
      box.hidden = true;
      return;
    }
    const r = node.getBoundingClientRect(),
      f = frame.getBoundingClientRect(),
      stage = $(".stage").getBoundingClientRect();
    box.hidden = r.width === 0 && r.height === 0;
    box.style.left = `${f.left + r.left - stage.left + $(".stage").scrollLeft}px`;
    box.style.top = `${f.top + r.top - stage.top + $(".stage").scrollTop}px`;
    box.style.width = `${r.width}px`;
    box.style.height = `${r.height}px`;
  }
  function updateOutline() {
    rectOverlay($(".selected"), selected);
    if (!selected) {
      contextual.hide();
      $("#handles").hidden = true;
      return;
    }
    const rect = selected.getBoundingClientRect();
    if (!drag) contextual.position(rect, frame.getBoundingClientRect());
    $(".selected").classList.toggle("cropping", cropMode);
    try {
      const quad = visualQuad(selected),
        f = frame.getBoundingClientRect(),
        stage = $(".stage").getBoundingClientRect();
      $("#handles").hidden =
        cropMode ||
        inline.active ||
        !(selected.localName === "img" || !canEditText(selected));
      for (const button of $("#handles").children) {
        const point = quad[button.dataset.corner];
        button.style.left = `${f.left + point.x - stage.left + $(".stage").scrollLeft}px`;
        button.style.top = `${f.top + point.y - stage.top + $(".stage").scrollTop}px`;
      }
    } catch {
      $("#handles").hidden = true;
    }
    const dimensions = $("#dimensions");
    if (dimensions)
      dimensions.textContent = `${Math.round(selected.offsetWidth)} × ${Math.round(selected.offsetHeight)} px`;
  }
  function choose(node) {
    inline.finish();
    cropMode = false;
    flush();
    if (!node) {
      selected = null;
      spec = null;
      renderPanel();
      updateOutline();
      return;
    }
    try {
      const existing = [...runtime.targets].find(
        ([, target]) => target === node,
      );
      spec = existing
        ? structuredClone(draft.find((e) => e.id === existing[0]))
        : identify(node);
      spec.changes = {};
      delete spec.content;
      selected = node;
      message(
        spec.strategy === "hierarchy"
          ? "Cible par hiérarchie : data-vt-id est conseillé pour la stabiliser."
          : "",
      );
      $(".selected span").textContent = labelFor(node);
      renderPanel();
      updateOutline();
    } catch (error) {
      message(error.message, true);
    }
  }
  function labelFor(node) {
    return node.localName === "img"
      ? "Image"
      : canEditText(node)
        ? node.localName.startsWith("h")
          ? "Titre"
          : node.localName === "a"
            ? "Lien"
            : "Texte"
        : ["section", "article"].includes(node.localName)
          ? "Bloc"
          : "Zone";
  }
  function group(title, key, open = false) {
    const details = document.createElement("details");
    details.open = open;
    details.dataset.group = key;
    const summary = document.createElement("summary");
    summary.textContent = title;
    details.append(summary);
    const fields = document.createElement("div");
    fields.className = "fields";
    details.append(fields);
    panel.append(details);
    return fields;
  }
  const choiceNames = {
    static: "Dans la page",
    relative: "Décalage autorisé",
    sticky: "Rester visible",
    auto: "Automatique",
    none: "Aucun",
    normal: "Normal",
    italic: "Italique",
    start: "Au début",
    end: "À la fin",
    left: "Gauche",
    right: "Droite",
    center: "Centré",
    justify: "Justifié",
    stretch: "Étirer",
    baseline: "Sur la ligne du texte",
    "space-between": "Répartir",
    "space-around": "Espacer autour",
    "space-evenly": "Espacer également",
    cover: "Remplir le cadre",
    contain: "Afficher en entier",
    fill: "Étirer",
    "scale-down": "Réduire si nécessaire",
    visible: "Afficher",
    hidden: "Masquer",
    solid: "Trait continu",
    dashed: "Tirets",
    dotted: "Points",
    uppercase: "MAJUSCULES",
    lowercase: "minuscules",
    capitalize: "Initiales",
    100: "Très fin",
    200: "Fin",
    300: "Léger",
    400: "Normal",
    500: "Moyen",
    600: "Semi-gras",
    700: "Gras",
    800: "Très gras",
    900: "Extra-gras",
  };
  function control(container, property, label, options = {}) {
    const wrap = document.createElement("label");
    wrap.className = "field";
    const title = document.createElement("span");
    title.textContent = label;
    if (
      mode !== "desktop" &&
      entry()?.changes[mode]?.[property] !== undefined
    ) {
      const badge = document.createElement("small");
      badge.className = "exception";
      badge.textContent = mode === "mobile" ? "Mobile" : "Tablette";
      title.append(badge);
    }
    wrap.append(title);
    const current = entry()?.changes[mode]?.[property];
    const effective = effectiveProperties(entry(), mode)[property];
    const computed = frame.contentWindow
      .getComputedStyle(selected)
      .getPropertyValue(property);
    const inherited =
      property === "translateX" || property === "translateY"
        ? "0px"
        : computed.trim();
    if (property === "opacity") {
      const range = document.createElement("input");
      range.type = "range";
      range.min = "0";
      range.max = "100";
      range.value = String(Math.round(Number(current ?? computed) * 100));
      range.dataset.property = property;
      const output = document.createElement("output");
      output.textContent = range.value + " %";
      wrap.append(range, output);
      range.addEventListener("input", () => {
        output.textContent = range.value + " %";
        setProperty(property, String(Number(range.value) / 100));
      });
      range.addEventListener("change", () => {
        if (!inline.active) flush();
      });
      container.append(wrap);
      return range;
    }
    if (["color", "background-color", "border-color"].includes(property)) {
      const color = colorControl(document, {
        label,
        value: current ?? toHex(computed) ?? effective ?? "",
        siteColors,
        storageKey: colorStorageKey,
        onChange: (value) => setProperty(property, value),
        onCommit: flush,
      });
      color.dataset.property = property;
      container.append(color);
      return color;
    }
    let input;
    if (options.choices) {
      input = document.createElement("select");
      for (const [value, name] of [
        ["", "Valeur du site"],
        ...options.choices.map((v) => [v, choiceNames[v] || v]),
      ]) {
        const option = document.createElement("option");
        option.value = value;
        option.textContent = name;
        input.append(option);
      }
    } else {
      input = document.createElement("input");
      input.type = "text";
      input.autocomplete = "off";
      input.spellcheck = false;
      input.placeholder = effective ?? inherited;
      input.title =
        "Entrez une valeur ; sans unité, la taille est en pixels. Vide : valeur du site.";
      if (!["z-index"].includes(property)) input.inputMode = "decimal";
    }
    input.value = current ?? "";
    input.dataset.property = property;
    input.addEventListener("input", () => {
      let value = input.value.trim();
      if (
        value &&
        /^-?(?:\d+\.?\d*|\.\d+)$/.test(value) &&
        !["opacity", "line-height", "z-index", "font-weight"].includes(property)
      )
        value += "px";
      const valid = value === "" || validValue(property, value);
      input.setCustomValidity(
        valid ? "" : "Cette valeur ne peut pas être utilisée.",
      );
      input.classList.toggle("invalid", !valid);
      if (valid) {
        setProperty(property, value);
        syncQuick();
      } else
        message(
          "Cette valeur ne convient pas. Le dernier réglage valide reste appliqué.",
          true,
        );
    });
    input.addEventListener("change", () => {
      if (!inline.active) flush();
    });
    wrap.append(input);
    container.append(wrap);
    return input;
  }
  function fontControl(container) {
    const label = document.createElement("label");
    label.className = "field full";
    label.textContent = "Police";
    const select = document.createElement("select");
    select.dataset.property = "font-family";
    select.setAttribute("aria-label", "Police");
    const computed = frame.contentWindow.getComputedStyle(selected).fontFamily;
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "Police du site";
    select.append(option);
    for (const name of fonts) {
      const option = document.createElement("option");
      option.value = '"' + name + '"';
      option.textContent = name;
      option.style.fontFamily = option.value;
      select.append(option);
    }
    const value = entry()?.changes[mode]?.["font-family"] ?? "";
    if (value && ![...select.options].some((o) => o.value === value)) {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = value.replaceAll('"', "");
      select.append(option);
    }
    select.value = value;
    select.title = computed;
    select.addEventListener("change", () => {
      setProperty("font-family", select.value);
      if (!inline.active) flush();
      syncQuick();
    });
    label.append(select);
    container.append(label);
  }
  function typography(container) {
    fontControl(container);
    control(container, "font-size", "Taille");
    control(container, "font-weight", "Graisse", {
      choices: ["300", "400", "500", "600", "700", "800", "900"],
    });
    control(container, "font-style", "Style", {
      choices: ["normal", "italic"],
    });
    control(container, "line-height", "Interligne");
    control(container, "letter-spacing", "Espacement des lettres");
    control(container, "text-transform", "Casse", {
      choices: ["none", "uppercase", "lowercase", "capitalize"],
    });
    control(container, "text-align", "Alignement", {
      choices: ["left", "center", "right", "justify"],
    });
  }
  function spacingControls(container) {
    for (const [prefix, label] of [
      ["margin", "Espace extérieur"],
      ["padding", "Espace intérieur"],
    ]) {
      const box = document.createElement("div");
      box.className = "spacing-box";
      const header = document.createElement("div");
      header.className = "spacing-title";
      header.textContent = label;
      const link = document.createElement("label");
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      link.append(checkbox, document.createTextNode(" Lier"));
      header.append(link);
      box.append(header);
      const grid = document.createElement("div");
      grid.className = "spacing-grid";
      box.append(grid);
      const inputs = ["top", "right", "bottom", "left"].map((side, index) => {
        const input = control(
          grid,
          `${prefix}-${side}`,
          ["Haut", "Droite", "Bas", "Gauche"][index],
        );
        input.parentElement.dataset.side = side;
        return input;
      });
      const center = document.createElement("span");
      center.className = "spacing-center";
      center.textContent = prefix === "margin" ? "Élément" : "Contenu";
      grid.append(center);
      for (const input of inputs)
        input.addEventListener("input", () => {
          if (checkbox.checked && input.checkValidity()) {
            let value = input.value.trim();
            if (value && /^-?[\d.]+$/.test(value)) value += "px";
            for (const sibling of inputs) {
              sibling.value = input.value;
              setProperty(sibling.dataset.property, value);
            }
          }
        });
      container.append(box);
    }
    const display = frame.contentWindow.getComputedStyle(selected).display;
    if (display.includes("flex") || display.includes("grid"))
      control(container, "gap", "Entre les éléments");
  }
  function alignment(container) {
    const display = frame.contentWindow.getComputedStyle(selected).display;
    if (display.includes("flex") || display.includes("grid")) {
      control(container, "align-items", "Aligner les éléments", {
        choices: ["start", "end", "center", "stretch", "baseline"],
      });
      control(container, "justify-content", "Répartir les éléments", {
        choices: [
          "start",
          "end",
          "center",
          "space-between",
          "space-around",
          "space-evenly",
        ],
      });
    } else
      control(container, "text-align", "Alignement", {
        choices: ["left", "center", "right", "justify"],
      });
  }
  function imageControls(container) {
    const replace = document.createElement("button");
    replace.textContent = "Remplacer l’image";
    replace.id = "replace-image";
    replace.className = "full";
    replace.addEventListener("click", replaceImage);
    container.append(replace);
    const choices = document.createElement("div");
    choices.className = "fit-options full";
    choices.setAttribute("aria-label", "Affichage de l’image");
    for (const [value, label] of [
      ["cover", "Remplir"],
      ["contain", "Tout afficher"],
      ["fill", "Étirer"],
    ]) {
      const button = document.createElement("button");
      button.textContent = label;
      button.dataset.fit = value;
      button.setAttribute(
        "aria-pressed",
        String(
          (effectiveProperties(entry(), mode)["object-fit"] ||
            frame.contentWindow.getComputedStyle(selected).objectFit) === value,
        ),
      );
      button.addEventListener("click", () => {
        setProperty("object-fit", value);
        flush();
        for (const sibling of choices.children)
          sibling.setAttribute("aria-pressed", String(sibling === button));
      });
      choices.append(button);
    }
    container.append(choices);
    const pad = document.createElement("div");
    pad.className = "crop-pad full";
    pad.setAttribute("role", "slider");
    pad.tabIndex = 0;
    pad.setAttribute("aria-label", "Position de l’image");
    pad.setAttribute("aria-valuemin", "0");
    pad.setAttribute("aria-valuemax", "100");
    const dot = document.createElement("span");
    pad.append(dot);
    container.append(pad);
    let values = (
      effectiveProperties(entry(), mode)["object-position"] ||
      frame.contentWindow.getComputedStyle(selected).objectPosition
    )
      .split(" ")
      .map(parseFloat);
    if (values.some((v) => !Number.isFinite(v))) values = [50, 50];
    const draw = () => {
      dot.style.left = values[0] + "%";
      dot.style.top = values[1] + "%";
      pad.setAttribute("aria-valuenow", String(values[0]));
      pad.setAttribute(
        "aria-valuetext",
        `Horizontal ${values[0]} %, vertical ${values[1]} %`,
      );
    };
    draw();
    const set = (event) => {
      const rect = pad.getBoundingClientRect();
      values = [
        Math.round(
          Math.max(
            0,
            Math.min(100, ((event.clientX - rect.left) / rect.width) * 100),
          ),
        ),
        Math.round(
          Math.max(
            0,
            Math.min(100, ((event.clientY - rect.top) / rect.height) * 100),
          ),
        ),
      ];
      draw();
      setProperty("object-position", `${values[0]}% ${values[1]}%`);
    };
    pad.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      pad.setPointerCapture(event.pointerId);
      pad.dataset.dragging = "yes";
      flush();
      set(event);
    });
    pad.addEventListener("pointermove", (event) => {
      if (pad.dataset.dragging) set(event);
    });
    const stop = () => {
      delete pad.dataset.dragging;
      flush();
    };
    pad.addEventListener("pointerup", stop);
    pad.addEventListener("pointercancel", stop);
    pad.addEventListener("keydown", (event) => {
      const axis = ["ArrowLeft", "ArrowRight"].includes(event.key) ? 0 : 1;
      if (
        !["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)
      )
        return;
      event.preventDefault();
      values[axis] = Math.max(
        0,
        Math.min(
          100,
          values[axis] +
            (["ArrowLeft", "ArrowUp"].includes(event.key) ? -5 : 5),
        ),
      );
      draw();
      setProperty("object-position", `${values[0]}% ${values[1]}%`);
      flush();
    });
    const hint = document.createElement("p");
    hint.className = "note full";
    hint.textContent =
      "Déplacez le point pour cadrer l’image, ou activez « Recadrer » pour la glisser dans son cadre.";
    container.append(hint);
    const center = document.createElement("button");
    center.textContent = "Centrer l’image";
    center.addEventListener("click", () => {
      values = [50, 50];
      draw();
      setProperty("object-position", "50% 50%");
      flush();
    });
    container.append(center);
    const crop = document.createElement("button");
    crop.textContent = cropMode
      ? "Terminer le cadrage"
      : "Recadrer dans la page";
    crop.addEventListener("click", toggleCrop);
    container.append(crop);
  }
  function renderPanel() {
    panel.replaceChildren();
    if (!selected) {
      const heading = document.createElement("h2");
      heading.textContent = "Cliquez, puis ajustez.";
      const help = document.createElement("p");
      help.textContent =
        "Choisissez un texte, une image ou une zone dans la page. Les actions utiles apparaîtront juste à côté.";
      panel.append(heading, help);
      if (draft.length) {
        const title = document.createElement("h3");
        title.textContent = "Vos retouches";
        panel.append(title);
        for (const item of draft) {
          const button = document.createElement("button");
          button.className = "target-list";
          button.textContent =
            item.fingerprint.tag === "img"
              ? "Image"
              : item.fingerprint.text?.slice(0, 45) || "Zone retouchée";
          button.addEventListener("click", () => {
            const node = runtime.targets.get(item.id);
            if (node) choose(node);
            else
              message(
                "Cet élément n’a pas été retrouvé. Ses retouches sont conservées.",
                true,
              );
          });
          panel.append(button);
        }
      }
      contextual.hide();
      return;
    }
    const head = document.createElement("div");
    head.className = "panel-heading";
    const heading = document.createElement("h2");
    heading.textContent = labelFor(selected);
    head.append(heading);
    const dimensions = document.createElement("span");
    dimensions.id = "dimensions";
    head.append(dimensions);
    panel.append(head);
    const modeInfo = document.createElement("p");
    modeInfo.className = "mode-note";
    modeInfo.textContent =
      mode === "desktop"
        ? "Réglages pour tous les écrans"
        : `Réglages ${mode === "mobile" ? "mobile" : "tablette"} · les valeurs personnalisées sont indiquées`;
    panel.append(modeInfo);
    const content = group("Contenu", "content", true);
    if (selected.localName === "img") imageControls(content);
    if (canEditText(selected)) {
      const edit = document.createElement("button");
      edit.className = "full primary";
      edit.textContent = inline.active
        ? "Terminer le texte"
        : "Modifier le texte dans la page";
      edit.dataset.inlineEdit = "";
      edit.addEventListener("click", () =>
        inline.active ? inline.finish() : startInline(),
      );
      content.append(edit);
      const wrap = document.createElement("label");
      wrap.className = "text-field";
      wrap.textContent = "Texte";
      const input = document.createElement("textarea");
      input.value = entry().content?.text ?? selected.textContent;
      input.maxLength = 4000;
      input.disabled = inline.active;
      input.addEventListener("input", () => {
        inline.finish();
        modify((item) => {
          item.content ||= {};
          item.content.text = input.value;
        });
      });
      input.addEventListener("change", flush);
      wrap.append(input);
      content.append(wrap);
    }
    if (selected.localName === "a") linkControl(content);
    if (!content.children.length) {
      const note = document.createElement("p");
      note.className = "note full";
      note.textContent =
        "Cette zone contient des éléments du site. Sélectionnez un texte ou une image pour en modifier le contenu.";
      content.append(note);
    }
    const sizes = group("Taille et position", "size");
    for (const [prop, label] of [
      ["width", "Largeur"],
      ["height", "Hauteur"],
      ["max-width", "Largeur maximale"],
      ["min-width", "Largeur minimale"],
      ["translateX", "Déplacer horizontalement"],
      ["translateY", "Déplacer verticalement"],
    ])
      control(sizes, prop, label);
    alignment(sizes);
    if (selected.localName === "img") {
      const label = document.createElement("label");
      label.className = "link-values full";
      const ratio = document.createElement("input");
      ratio.type = "checkbox";
      ratio.checked = lockRatio;
      ratio.addEventListener("change", () => (lockRatio = ratio.checked));
      label.append(
        ratio,
        document.createTextNode(" Conserver les proportions"),
      );
      sizes.append(label);
    }
    spacingControls(group("Espacement", "spacing"));
    const appearance = group("Style", "style");
    control(appearance, "background-color", "Fond");
    if (selected.localName !== "img") control(appearance, "color", "Couleur");
    for (const [prop, label] of [
      ["border-radius", "Arrondi"],
      ["opacity", "Opacité"],
      ["border-width", "Épaisseur de bordure"],
    ])
      control(appearance, prop, label);
    control(appearance, "border-style", "Bordure", {
      choices: ["none", "solid", "dashed", "dotted"],
    });
    control(appearance, "border-color", "Couleur de bordure");
    if (selected.localName !== "img" && selected.textContent.trim())
      typography(group("Texte", "text"));
    const responsive = group("Responsive", "responsive");
    const note = document.createElement("p");
    note.className = "note full";
    note.textContent =
      "Choisissez l’écran en haut. Les réglages du site sont conservés tant que vous ne les personnalisez pas.";
    responsive.append(note);
    control(responsive, "visibility", "Afficher cet élément", {
      choices: ["visible", "hidden"],
    });
    const advanced = group("Réglages avancés", "advanced");
    control(advanced, "position", "Comportement", {
      choices: ["static", "relative", "sticky"],
    });
    control(advanced, "z-index", "Ordre des plans");
    const info = document.createElement("div");
    info.className = "info full";
    for (const text of [
      `<${selected.localName}>${selected.id ? ` #${selected.id}` : ""}`,
      [...selected.classList].join(" "),
      spec.selector,
    ]) {
      const line = document.createElement("code");
      line.textContent = text;
      info.append(line);
    }
    advanced.append(info);
    const reset = document.createElement("button");
    reset.textContent = "Réinitialiser cet élément";
    reset.id = "reset-element";
    reset.className = "reset-element";
    reset.addEventListener("click", () => {
      if (recoveryPending) {
        message("Récupérez le brouillon avant de réinitialiser.", true);
        return;
      }
      inline.finish();
      flush();
      draft = draft.filter((e) => e.id !== spec.id);
      history.push(draft);
      preview();
      renderPanel();
      message("Élément réinitialisé. Enregistrez pour conserver ce retour.");
    });
    panel.append(reset);
    renderContext();
    updateOutline();
  }
  function replaceImage() {
    inline.finish();
    if (!window.wp?.media) {
      message("La médiathèque n’est pas disponible.", true);
      return;
    }
    const targetId = spec.id;
    const media = window.wp.media({
      title: "Remplacer cette image",
      library: { type: "image" },
      button: { text: "Utiliser cette image" },
      multiple: false,
    });
    media.on("select", () => {
      if (spec?.id !== targetId) return;
      const asset = media.state().get("selection").first().toJSON();
      flush();
      modify((item) => {
        item.content ||= {};
        item.content.attachmentId = asset.id;
        item.content.image = { src: asset.url, alt: asset.alt || "" };
      });
      flush();
      message("Image remplacée. Enregistrez pour conserver ce choix.");
    });
    media.open();
    media.content.mode("browse");
  }
  function linkControl(container) {
    const label = document.createElement("label");
    label.className = "field full";
    label.textContent = "Adresse du lien";
    const input = document.createElement("input");
    input.type = "text";
    input.value = entry().content?.href ?? selected.getAttribute("href") ?? "";
    input.placeholder = "https://… ou /une-page";
    input.setAttribute("aria-label", "Adresse du lien");
    input.addEventListener("input", () => {
      const value = input.value.trim();
      const valid = validHref(value);
      input.classList.toggle("invalid", !valid);
      input.setCustomValidity(
        valid ? "" : "Utilisez une adresse web ou un chemin relatif.",
      );
      if (valid)
        modify((item) => {
          item.content ||= {};
          item.content.href = value;
        });
      else message("Cette adresse de lien est refusée.", true);
    });
    input.addEventListener("change", flush);
    label.append(input);
    container.append(label);
  }
  function startInline() {
    if (!selected || !canEditText(selected) || recoveryPending) {
      message(
        "Ce texte contient des éléments imbriqués ou un brouillon attend votre décision.",
        true,
      );
      return;
    }
    cropMode = false;
    flush();
    inlineSnapshot = structuredClone(draft);
    if (inline.start(selected)) {
      message(
        "Écrivez directement dans la page. « Terminer » valide le texte ; Échap annule cette édition.",
      );
      renderPanel();
      updateOutline();
    }
  }
  function openQuick(kind) {
    cropMode = false;
    updateOutline();
    const titles = {
      text: "Style du texte",
      color: "Couleur",
      alignment: "Alignement",
      size: "Taille",
      style: "Style de l’image",
      spacing: "Espacement",
      background: "Fond",
      link: "Lien",
    };
    contextual.open(titles[kind] || "Réglages", (container) => {
      if (kind === "text") typography(container);
      if (kind === "color") control(container, "color", "Couleur");
      if (kind === "background") control(container, "background-color", "Fond");
      if (kind === "alignment") alignment(container);
      if (kind === "spacing") spacingControls(container);
      if (kind === "size") {
        control(container, "width", "Largeur");
        control(container, "height", "Hauteur");
        control(container, "max-width", "Largeur maximale");
      }
      if (kind === "style") {
        control(container, "border-radius", "Arrondi");
        control(container, "opacity", "Opacité");
      }
      if (kind === "link") linkControl(container);
    });
    updateOutline();
  }
  function toggleStyle(property, onValue, offValue) {
    const current =
      effectiveProperties(entry(), mode)[property] ||
      frame.contentWindow.getComputedStyle(selected).getPropertyValue(property);
    setProperty(property, current === onValue ? offValue : onValue);
    if (!inline.active) flush();
    syncQuick();
  }
  function renderContext() {
    if (!selected) {
      contextual.hide();
      return;
    }
    const action = (id, label, run, active) => ({ id, label, run, active });
    let actions;
    if (canEditText(selected)) {
      actions = [
        action("edit", inline.active ? "Terminer" : "Modifier", () =>
          inline.active ? inline.finish() : startInline(),
        ),
        action(
          "bold",
          "Gras",
          () => toggleStyle("font-weight", "700", "400"),
          parseInt(frame.contentWindow.getComputedStyle(selected).fontWeight) >=
            700,
        ),
        action(
          "italic",
          "Italique",
          () => toggleStyle("font-style", "italic", "normal"),
          frame.contentWindow.getComputedStyle(selected).fontStyle === "italic",
        ),
        action("text", "Police / Taille", () => openQuick("text")),
        action("color", "Couleur", () => openQuick("color")),
        action(
          selected.localName === "a" ? "link" : "alignment",
          selected.localName === "a" ? "Lien" : "Aligner",
          () => openQuick(selected.localName === "a" ? "link" : "alignment"),
        ),
      ];
    } else if (selected.localName === "img")
      actions = [
        action("replace", "Remplacer", replaceImage),
        action(
          "crop",
          cropMode ? "Terminer" : "Recadrer",
          toggleCrop,
          cropMode,
        ),
        action("size", "Taille", () => openQuick("size")),
        action("style", "Arrondi / Opacité", () => openQuick("style")),
      ];
    else
      actions = [
        action("spacing", "Espacement", () => openQuick("spacing")),
        action("alignment", "Aligner", () => openQuick("alignment")),
        action("background", "Fond", () => openQuick("background")),
        action("size", "Taille", () => openQuick("size")),
      ];
    contextual.setActions(actions);
    const badge = document.createElement("small");
    badge.className = "context-mode";
    badge.textContent =
      mode === "desktop"
        ? "Tous les écrans"
        : mode === "mobile"
          ? "Mobile"
          : "Tablette";
    contextual.bar.prepend(badge);
    syncQuick();
  }
  function syncQuick() {
    if (!selected) return;
    const style = frame.contentWindow.getComputedStyle(selected);
    for (const [id, active] of [
      ["bold", parseInt(style.fontWeight) >= 700],
      ["italic", style.fontStyle === "italic"],
    ]) {
      const button = contextual.bar.querySelector(`[data-action="${id}"]`);
      if (button) {
        button.classList.toggle("active", active);
        button.setAttribute("aria-pressed", String(active));
      }
    }
    for (const button of ui.querySelectorAll("[data-mode]"))
      button.classList.toggle(
        "has-exceptions",
        button.dataset.mode !== "desktop" &&
          !!Object.keys(entry()?.changes[button.dataset.mode] || {}).length,
      );
  }
  function toggleCrop() {
    inline.finish();
    cropMode = !cropMode;
    if (cropMode) {
      setProperty("object-fit", "cover");
      flush();
      message(
        "Glissez l’image à l’intérieur de son cadre pour ajuster le cadrage.",
      );
    } else message("Cadrage terminé.");
    renderContext();
    updateOutline();
  }
  function setMode(value) {
    if (drag) cancelGesture();
    inline.finish();
    cropMode = false;
    flush();
    mode = value;
    const available = $(".stage").clientWidth - 48;
    const width = {
      desktop: Math.max(1100, available),
      tablet: 820,
      mobile: 390,
    }[mode];
    frame.style.width = `${width}px`;
    frame.style.height = "100%";
    for (const button of ui.querySelectorAll("[data-mode]")) {
      const active = button.dataset.mode === mode;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(active));
    }
    renderPanel();
    $(".hover").hidden = true;
    requestAnimationFrame(updateOutline);
  }
  for (const button of ui.querySelectorAll("[data-mode]"))
    button.addEventListener("click", () => setMode(button.dataset.mode));
  function undo(redo = false) {
    inline.finish();
    cropMode = false;
    flush();
    draft = redo ? history.redo() : history.undo();
    preview();
    if (spec && !selected?.isConnected) choose(null);
    else renderPanel();
  }
  $("#undo").addEventListener("click", () => undo());
  $("#redo").addEventListener("click", () => undo(true));
  function keyboard(event) {
    if (event.key === "Escape") {
      if (drag) {
        cancelGesture();
        return;
      }
      if (inline.active) {
        inline.cancel();
        return;
      }
      if (cropMode) {
        cropMode = false;
        renderContext();
        updateOutline();
        return;
      }
      choose(null);
      return;
    }
    if (
      (event.ctrlKey || event.metaKey) &&
      event.key.toLowerCase() === "z" &&
      !event
        .composedPath()[0]
        ?.closest?.("input,textarea,select,[contenteditable]")
    ) {
      event.preventDefault();
      undo(event.shiftKey);
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      save();
    }
  }
  document.addEventListener("keydown", keyboard);
  window.addEventListener("beforeunload", (event) => {
    if (dirty()) {
      event.preventDefault();
      event.returnValue = "";
    }
  });
  async function save() {
    inline.finish();
    if (busy || !dirty() || !runtime) return;
    flush();
    busy = true;
    status();
    const payload = structuredClone(draft);
    try {
      const response = await fetch(config.editor.api, {
        method: "PUT",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
          "X-WP-Nonce": config.editor.nonce,
        },
        body: JSON.stringify({
          page: config.page,
          revision,
          elements: payload,
        }),
      });
      const data = await response.json();
      if (!response.ok)
        throw new Error(data.message || `Erreur ${response.status}`);
      revision = data.revision;
      // Inputs remain usable while saving: acknowledge only the submitted snapshot.
      saved = JSON.stringify(payload);
      message(
        dirty()
          ? "Sauvegarde effectuée. De nouvelles retouches restent à enregistrer."
          : "Réglages enregistrés dans WordPress.",
      );
    } catch (error) {
      message(
        `Sauvegarde impossible : ${error.message} Le brouillon est conservé.`,
        true,
      );
    } finally {
      busy = false;
      status();
    }
  }
  $("#save").addEventListener("click", save);
  $("#export").addEventListener("click", () => {
    inline.finish();
    flush();
    const blob = new Blob(
      [
        JSON.stringify(
          {
            schemaVersion: 1,
            page: config.page,
            revision,
            breakpoints: config.breakpoints,
            elements: draft,
          },
          null,
          2,
        ),
      ],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob),
      a = document.createElement("a");
    a.href = url;
    a.download = "visual-tweaks-draft.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    message("Brouillon exporté.");
  });
  $("#reset-page").addEventListener("click", () => {
    if (recoveryPending) {
      message(
        "Récupérez le brouillon local ou revenez à la sauvegarde avant de réinitialiser.",
        true,
      );
      return;
    }
    inline.finish();
    if (
      !confirm(
        "Retirer toutes les retouches de cette page ? Ce reset reste annulable avant et après sauvegarde dans cette session.",
      )
    )
      return;
    flush();
    draft = [];
    history.push(draft);
    preview();
    choose(null);
    message(
      "Page réinitialisée dans le brouillon. Enregistrez pour conserver ce reset.",
    );
  });
  $("#discard").addEventListener("click", () => {
    inline.finish();
    flush();
    recoveryPending = false;
    $("#recovery").replaceChildren();
    draft = JSON.parse(saved);
    history.push(draft);
    preview();
    renderPanel();
    message("Retour à la dernière sauvegarde.");
  });
  $("#exit").addEventListener("click", () => {
    inline.finish();
    flush();
    if (
      dirty() &&
      !confirm(
        "Quitter avec des retouches non enregistrées ? Le brouillon local reste disponible sur ce navigateur.",
      )
    )
      return;
    const url = new URL(location.href);
    url.searchParams.delete("vt-edit");
    url.searchParams.delete("vt-frame");
    location.href = url.href;
  });
  if (recoveryPending) {
    const recovery = $("#recovery");
    const restore = document.createElement("button");
    restore.textContent = "Récupérer le brouillon local";
    recovery.append(restore);
    restore.addEventListener("click", () => {
      flush();
      recoveryPending = false;
      draft = structuredClone(recovered.elements);
      history.push(draft);
      revision = recovered.revision;
      preview();
      renderPanel();
      recovery.replaceChildren();
      message(
        revision !== config.revision
          ? "Brouillon récupéré sur une ancienne version. Exportez-le : la sauvegarde sera refusée pour préserver la version actuelle."
          : "Brouillon local récupéré.",
        revision !== config.revision,
      );
    });
  }
  // Keep WordPress media dialogs above the editor host, outside its isolated styles.
  const mediaStyle = document.createElement("style");
  mediaStyle.textContent =
    ".media-modal{z-index:2147483646!important}.media-modal-backdrop{z-index:2147483645!important}";
  document.head.append(mediaStyle);
  frame.addEventListener("load", () => {
    try {
      const doc = frame.contentDocument;
      runtime = frame.contentWindow.VisualTweaksRuntime;
      if (!runtime) {
        message(
          "Le runtime de la page est indisponible. Vérifiez que le thème appelle wp_footer().",
          true,
        );
        return;
      }
      doc.addEventListener(
        "pointermove",
        (event) => {
          if (drag || inline.active) return;
          const node = event.target;
          if (editable(node) && node !== selected) {
            $(".hover span").textContent = labelFor(node);
            rectOverlay($(".hover"), node);
          } else $(".hover").hidden = true;
        },
        true,
      );
      doc.addEventListener(
        "click",
        (event) => {
          if (inline.contains(event.target)) return;
          event.preventDefault();
          event.stopImmediatePropagation();
          if (dragSuppress) {
            dragSuppress = false;
            return;
          }
          if (cropMode && event.target === selected) return;
          if (editable(event.target)) choose(event.target);
        },
        true,
      );
      doc.addEventListener(
        "dblclick",
        (event) => {
          if (inline.active) return;
          event.preventDefault();
          event.stopImmediatePropagation();
          if (editable(event.target) && canEditText(event.target)) {
            choose(event.target);
            startInline();
          }
        },
        true,
      );
      doc.addEventListener(
        "pointerdown",
        (event) => {
          if (inline.contains(event.target)) return;
          if (inline.active) inline.finish();
          if (
            event.target === selected &&
            (cropMode || selected.localName === "img")
          )
            beginGesture(event, cropMode ? "crop" : "move");
        },
        true,
      );
      doc.addEventListener(
        "submit",
        (event) => {
          event.preventDefault();
          event.stopImmediatePropagation();
        },
        true,
      );
      doc.addEventListener("keydown", keyboard, true);
      doc.addEventListener(
        "scroll",
        () => {
          $(".hover").hidden = true;
          updateOutline();
        },
        true,
      );
      doc.defaultView.addEventListener("resize", updateOutline);
      fonts = discoverFonts(doc);
      siteColors = discoverColors(doc);
      const editingStyle = doc.createElement("style");
      editingStyle.textContent =
        "[data-vt-inline-edit]{outline:2px solid #10a477!important;outline-offset:4px;white-space:pre-wrap!important;cursor:text!important;min-height:1em}";
      doc.head.append(editingStyle);
      preview();
      renderPanel();
      message("Prêt. Cliquez sur un élément dans la page.");
    } catch {
      message(
        "Aperçu inaccessible. Cette page doit autoriser une iframe de même origine.",
        true,
      );
    }
  });
  $(".stage").addEventListener("scroll", () => {
    $(".hover").hidden = true;
    updateOutline();
  });
  let dragSuppress = false;
  const handles = $("#handles");
  for (const corner of ["nw", "ne", "se", "sw"]) {
    const button = document.createElement("button");
    button.className = `resize-handle ${corner}`;
    button.dataset.corner = corner;
    button.title = "Glisser pour redimensionner. Maj : proportions libres.";
    const cornerLabel = {
      nw: "coin supérieur gauche",
      ne: "coin supérieur droit",
      se: "coin inférieur droit",
      sw: "coin inférieur gauche",
    };
    button.setAttribute(
      "aria-label",
      `Redimensionner — ${cornerLabel[corner]}`,
    );
    button.addEventListener("pointerdown", (event) =>
      beginGesture(event, "resize", corner),
    );
    handles.append(button);
  }
  function beginGesture(event, kind, corner = null) {
    if (!selected || recoveryPending || event.button !== 0) return;
    inline.finish();
    flush();
    const values = effectiveProperties(entry(), mode),
      style = frame.contentWindow.getComputedStyle(selected);
    const x = values.translateX || "0px",
      y = values.translateY || "0px";
    if (![x, y].every((v) => /^-?[\d.]+(?:px)?$/.test(v)) && kind !== "crop") {
      message(
        "Ce décalage utilise une unité relative. Ajustez-le dans Taille et position avant de le déplacer.",
        true,
      );
      return;
    }
    try {
      const own = matrixFor(selected),
        parent = selected.parentElement
          ? matrixFor(selected.parentElement)
          : new frame.contentWindow.DOMMatrix();
      const quad = visualQuad(selected),
        opposite = { nw: "se", ne: "sw", se: "nw", sw: "ne" }[corner];
      drag = {
        kind,
        corner,
        x: event.clientX,
        y: event.clientY,
        target: event.target,
        baseX: parseFloat(x) || 0,
        baseY: parseFloat(y) || 0,
        matrix: own,
        parent,
        width: selected.offsetWidth,
        height: selected.offsetHeight,
        offsetW: selected.offsetWidth - parseFloat(style.width),
        offsetH: selected.offsetHeight - parseFloat(style.height),
        ratio: selected.localName === "img" && lockRatio && !event.shiftKey,
        anchor: opposite ? quad[opposite] : null,
        opposite,
        position: (values["object-position"] || style.objectPosition)
          .split(" ")
          .map(parseFloat),
        moved: false,
        snapshot: structuredClone(draft),
      };
      event.preventDefault();
      event.stopImmediatePropagation();
      event.target.setPointerCapture(event.pointerId);
      event.target.addEventListener("pointermove", moveGesture);
      event.target.addEventListener("pointerup", endGesture);
      event.target.addEventListener("pointercancel", cancelGesture);
      event.target.addEventListener("lostpointercapture", cancelGesture);
      contextual.root.hidden = true;
    } catch (error) {
      message(error.message, true);
    }
  }
  function moveGesture(event) {
    if (!drag) return;
    const dx = event.clientX - drag.x,
      dy = event.clientY - drag.y;
    if (!drag.moved && Math.hypot(dx, dy) < 3) return;
    drag.moved = true;
    if (drag.kind === "move") {
      const delta = localDelta(drag.parent, dx, dy);
      modify((item) => {
        item.changes[mode] ||= {};
        item.changes[mode].translateX = `${Math.round(drag.baseX + delta.x)}px`;
        item.changes[mode].translateY = `${Math.round(drag.baseY + delta.y)}px`;
      });
      feedback(
        `Déplacer : ${Math.round(delta.x)} / ${Math.round(delta.y)} px`,
        event,
      );
    } else if (drag.kind === "resize") {
      const delta = localDelta(drag.matrix, dx, dy);
      const size = resizeDimensions({
        width: drag.width,
        height: drag.height,
        dx: delta.x,
        dy: delta.y,
        corner: drag.corner,
        ratio: drag.ratio,
      });
      const width = Math.max(12, size.width - drag.offsetW),
        height = Math.max(12, size.height - drag.offsetH);
      modify((item) => {
        item.changes[mode] ||= {};
        Object.assign(item.changes[mode], {
          width: `${width}px`,
          height: `${height}px`,
          "max-width": `${width}px`,
          translateX: `${drag.baseX}px`,
          translateY: `${drag.baseY}px`,
        });
      });
      const current = visualQuad(selected)[drag.opposite];
      const compensation = localDelta(
        drag.parent,
        drag.anchor.x - current.x,
        drag.anchor.y - current.y,
      );
      modify((item) => {
        item.changes[mode].translateX =
          `${Math.round(drag.baseX + compensation.x)}px`;
        item.changes[mode].translateY =
          `${Math.round(drag.baseY + compensation.y)}px`;
      });
      feedback(`${Math.round(width)} × ${Math.round(height)} px`, event);
    } else {
      const delta = localDelta(drag.matrix, dx, dy);
      const naturalW = selected.naturalWidth || selected.offsetWidth,
        naturalH = selected.naturalHeight || selected.offsetHeight;
      const scale = Math.max(
        selected.clientWidth / naturalW,
        selected.clientHeight / naturalH,
      );
      const overflowX = naturalW * scale - selected.clientWidth,
        overflowY = naturalH * scale - selected.clientHeight;
      const px =
        overflowX > 1
          ? Math.max(
              0,
              Math.min(
                100,
                (drag.position[0] || 0) - (delta.x / overflowX) * 100,
              ),
            )
          : 50;
      const py =
        overflowY > 1
          ? Math.max(
              0,
              Math.min(
                100,
                (drag.position[1] || 0) - (delta.y / overflowY) * 100,
              ),
            )
          : 50;
      modify((item) => {
        item.changes[mode] ||= {};
        item.changes[mode]["object-position"] =
          `${Math.round(px)}% ${Math.round(py)}%`;
      });
      feedback("Position de l’image", event);
    }
  }
  function feedback(text, event) {
    const box = $(".gesture-feedback");
    const stage = $(".stage").getBoundingClientRect();
    const origin =
      event.target.ownerDocument === document
        ? { left: 0, top: 0 }
        : frame.getBoundingClientRect();
    box.hidden = false;
    box.textContent = text;
    box.style.left = `${Math.max($(".stage").scrollLeft + 8, Math.min($(".stage").scrollLeft + $(".stage").clientWidth - 180, event.clientX + origin.left - stage.left + $(".stage").scrollLeft + 15))}px`;
    box.style.top = `${event.clientY + origin.top - stage.top + $(".stage").scrollTop + 18}px`;
  }
  function cleanupGesture() {
    if (!drag) return;
    const { target } = drag;
    target.removeEventListener("pointermove", moveGesture);
    target.removeEventListener("pointerup", endGesture);
    target.removeEventListener("pointercancel", cancelGesture);
    target.removeEventListener("lostpointercapture", cancelGesture);
    $(".gesture-feedback").hidden = true;
  }
  function endGesture(event) {
    if (!drag) return;
    const moved = drag.moved;
    const inFrame = drag.target.ownerDocument !== document;
    cleanupGesture();
    drag = null;
    flush();
    if (moved && inFrame) {
      dragSuppress = true;
      setTimeout(() => (dragSuppress = false), 50);
    }
    renderPanel();
  }
  function cancelGesture() {
    if (!drag) return;
    const previous = drag.snapshot;
    cleanupGesture();
    drag = null;
    draft = previous;
    preview();
    renderPanel();
  }
  $(".drag").addEventListener("pointerdown", (event) =>
    beginGesture(event, "move"),
  );
  $(".hover").hidden = true;
  $(".selected").hidden = true;
  const url = new URL(location.href);
  url.searchParams.delete("vt-edit");
  url.searchParams.set("vt-frame", "1");
  frame.src = url.href;
  setMode("desktop");
  renderPanel();
  status();
  css.addEventListener("load", () => setMode(mode));
  window.addEventListener("resize", () => {
    if (mode === "desktop")
      frame.style.width = `${Math.max(1100, $(".stage").clientWidth - 48)}px`;
  });
}
