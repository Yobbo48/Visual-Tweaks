import {
  editable,
  selectionTarget,
  backgroundSource,
  canEditText,
} from "./selection.js?ver=0.3.0";
export function assetInfo(node) {
  if (!node) return null;
  if (node.localName === "img")
    return {
      kind: "image",
      type:
        node.parentElement?.localName === "picture"
          ? "Image adaptative"
          : "Image",
      src: node.currentSrc || node.src,
      replaceable: true,
      name: node.alt,
    };
  if (node.localName === "svg")
    return {
      kind: "svg",
      type: "Icône SVG",
      src: "",
      replaceable: false,
      name:
        node.getAttribute("aria-label") ||
        node.querySelector("title")?.textContent ||
        "Icône",
    };
  const background = backgroundSource(node);
  if (background)
    return {
      kind: "background",
      type: "Image de fond",
      ...background,
      replaceable:
        backgroundSource(
          node,
          node.ownerDocument.defaultView.VisualTweaksRuntime?.originals.get(
            node,
          )?.background,
        )?.replaceable ?? background.replaceable,
      name: node.getAttribute("aria-label") || "",
    };
  return null;
}
export function labelFor(node) {
  const asset = assetInfo(node);
  if (asset)
    return asset.kind === "svg"
      ? "Icône"
      : asset.kind === "background"
        ? "Image de fond"
        : "Image";
  if (["a", "button"].includes(node.localName)) return "Bouton";
  if (canEditText(node))
    return node.localName.startsWith("h") ? "Titre" : "Texte";
  if (node.localName === "section") return "Section";
  return "Zone";
}
export function assetInventory(doc) {
  const list = [],
    seen = new Set();
  const nodes = [...doc.querySelectorAll("body *")].slice(0, 5000);
  for (const candidate of nodes) {
    const node = selectionTarget(candidate);
    if (!node || seen.has(node)) continue;
    seen.add(node);
    const asset = assetInfo(node);
    if (!asset) continue;
    let filename = "";
    try {
      filename = decodeURIComponent(
        new URL(asset.src, doc.baseURI).pathname.split("/").pop(),
      );
    } catch {}
    const zone = node.parentElement?.closest(
      "header,footer,section,article,main,figure",
    );
    const area =
      zone?.getAttribute("aria-label") ||
      zone?.querySelector("h1,h2,h3")?.textContent?.trim().slice(0, 55) ||
      ({
        header: "En-tête",
        footer: "Pied de page",
        main: "Page",
        section: "Section",
        article: "Bloc",
        figure: "Illustration",
      }[zone?.localName] ??
        "Page");
    list.push({
      ...asset,
      node,
      name: (asset.name || filename || asset.type).slice(0, 90),
      area,
      width: node.offsetWidth ?? Math.round(node.getBoundingClientRect().width),
      height:
        node.offsetHeight ?? Math.round(node.getBoundingClientRect().height),
    });
    if (list.length >= 200) break;
  }
  return list;
}
export function structureInventory(doc) {
  const list = [];
  function visit(parent, depth) {
    for (const node of parent.children) {
      if (list.length >= 200 || depth > 6) return;
      if (!editable(node)) continue;
      const relevant =
        assetInfo(node) ||
        canEditText(node) ||
        [
          "header",
          "footer",
          "main",
          "section",
          "article",
          "nav",
          "figure",
        ].includes(node.localName);
      if (relevant)
        list.push({
          node,
          depth,
          label:
            node.getAttribute("aria-label") ||
            { header: "En-tête", footer: "Pied de page", main: "Page" }[
              node.localName
            ] ||
            (canEditText(node)
              ? node.textContent.trim().slice(0, 50)
              : labelFor(node)),
        });
      if (!assetInfo(node) && !canEditText(node))
        visit(node, depth + (relevant ? 1 : 0));
    }
  }
  visit(doc.body, 0);
  return list;
}

// Thumbnail copies only graphic primitives; no scripts, foreignObject, links or events.
export function svgThumbnail(source, doc) {
  const tags = new Set([
    "svg",
    "g",
    "path",
    "circle",
    "ellipse",
    "rect",
    "line",
    "polyline",
    "polygon",
  ]);
  const attributes = new Set([
    "viewBox",
    "d",
    "cx",
    "cy",
    "r",
    "rx",
    "ry",
    "x",
    "y",
    "x1",
    "y1",
    "x2",
    "y2",
    "width",
    "height",
    "points",
    "fill",
    "stroke",
    "stroke-width",
    "stroke-linecap",
    "stroke-linejoin",
    "fill-rule",
    "opacity",
    "transform",
  ]);
  function copy(node) {
    if (!tags.has(node.localName)) return null;
    const clone = doc.createElementNS(
      "http://www.w3.org/2000/svg",
      node.localName,
    );
    for (const attribute of node.attributes) {
      if (
        attributes.has(attribute.name) &&
        attribute.value.length <= 16000 &&
        !/url\s*\(/i.test(attribute.value)
      )
        clone.setAttribute(attribute.name, attribute.value);
    }
    for (const child of node.children) {
      const safe = copy(child);
      if (safe) clone.append(safe);
    }
    return clone;
  }
  const thumb = copy(source);
  thumb.setAttribute("aria-hidden", "true");
  thumb.setAttribute("focusable", "false");
  thumb.style.color =
    source.ownerDocument.defaultView.getComputedStyle(source).color;
  return thumb;
}
