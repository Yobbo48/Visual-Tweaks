// PHP serializes empty arrays as []; these fields are maps, including in old drafts.
export function normalizeElements(elements) {
  return structuredClone(elements).map((element) => {
    element.changes = Object.assign({}, element.changes);
    for (const mode of Object.keys(element.changes))
      element.changes[mode] = Object.assign({}, element.changes[mode]);
    return element;
  });
}
