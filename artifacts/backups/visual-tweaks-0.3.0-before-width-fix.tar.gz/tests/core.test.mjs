import test from "node:test";
import assert from "node:assert/strict";
import { History } from "../visual-tweaks/assets/history.js";
import {
  generateCSS,
  effectiveProperties,
} from "../visual-tweaks/assets/styles.js";
import { validValue, validHref } from "../visual-tweaks/assets/validation.js";
import {
  resizeDimensions,
  localDelta,
} from "../visual-tweaks/assets/geometry.js";
import { toHex } from "../visual-tweaks/assets/appearance-controls.js";
test("undo/redo preserve snapshots and truncate obsolete branches", () => {
  const history = new History([]);
  const value = [{ id: "phone", x: 1 }];
  history.push(value);
  value[0].x = 99;
  assert.deepEqual(history.undo(), []);
  assert.deepEqual(history.redo(), [{ id: "phone", x: 1 }]);
  history.undo();
  history.push([{ id: "title" }]);
  assert.equal(history.canRedo, false);
});
test("new font and link values are bounded and reject executable schemes", () => {
  assert.equal(
    validValue("font-family", '"Instrument Sans", sans-serif'),
    true,
  );
  for (const value of ["url(https://x)", "Arial; color: red", '"Bad\\font"'])
    assert.equal(validValue("font-family", value), false);
  for (const url of [
    "javascript:alert(1)",
    "data:text/html,<script>",
    "//evil.test",
    "java\nscript:alert(1)",
  ])
    assert.equal(validHref(url), false);
  for (const url of [
    "https://example.test/a",
    "/contact",
    "#hero",
    "mailto:a@example.test",
    "tel:+33000000000",
  ])
    assert.equal(validHref(url), true);
});
test("resize follows local axes and keeps image proportions by default", () => {
  const a = Math.cos(Math.PI / 4),
    b = Math.sin(Math.PI / 4);
  const delta = localDelta({ a, b, c: -b, d: a }, a * 40, b * 40);
  assert.ok(Math.abs(delta.x - 40) < 0.001);
  assert.ok(Math.abs(delta.y) < 0.001);
  const size = resizeDimensions({
    width: 200,
    height: 100,
    dx: 40,
    dy: 20,
    corner: "se",
    ratio: true,
  });
  assert.deepEqual(size, { width: 240, height: 120 });
  assert.deepEqual(
    resizeDimensions({
      width: 200,
      height: 100,
      dx: 40,
      dy: 20,
      corner: "se",
      ratio: false,
    }),
    { width: 240, height: 120 },
  );
  const free = resizeDimensions({
    width: 200,
    height: 100,
    dx: 40,
    dy: 0,
    corner: "se",
    ratio: false,
  });
  assert.deepEqual(free, { width: 240, height: 100 });
});
test("site palette extracts colors without treating transparency as opaque", () => {
  assert.equal(toHex("rgb(23, 61, 48)"), "#173d30");
  assert.equal(toHex("rgba(0, 0, 0, 0)"), null);
  assert.equal(toHex("#abc"), "#aabbcc");
});
test("controls refuse CSS injection, unsupported values and negative dimensions", () => {
  for (const value of [
    "url(javascript:alert(1))",
    "10px;color:red",
    "var(--secret)",
    "calc(100% - 1px)",
    "-20px",
    "20",
  ])
    assert.equal(validValue("width", value), false);
  assert.equal(validValue("translateY", "-25px"), true);
  assert.equal(validValue("padding-top", "-1px"), false);
  assert.equal(validValue("color", "#aabbcc"), true);
  assert.equal(validValue("object-position", "100.01% 50%"), false);
});
test("responsive generation groups exceptions in at most two media queries", () => {
  const elements = Array.from({ length: 20 }, (_, i) => ({
    id: `phone-${i}`,
    selector: ".phone",
    changes: {
      desktop: {
        translateX: "20px",
        translateY: "-25px",
        "max-width": "280px",
      },
      tablet: { translateY: "-10px" },
      mobile: { translateX: "0px", "font-size": "16px" },
    },
  }));
  const css = generateCSS(elements);
  assert.equal((css.match(/@media/g) || []).length, 2);
  assert.ok(
    css.includes(
      "calc(var(--vt-base-x, 0px) + 20px) calc(var(--vt-base-y, 0px) + -10px)",
    ),
  );
  assert.ok(
    css.includes(
      "calc(var(--vt-base-x, 0px) + 0px) calc(var(--vt-base-y, 0px) + -10px)",
    ),
  );
  assert.equal(css.includes("transform:"), false);
  assert.deepEqual(effectiveProperties(elements[0], "mobile"), {
    translateX: "0px",
    translateY: "-10px",
    "max-width": "280px",
    "font-size": "16px",
  });
});

import { normalizeElements } from "../visual-tweaks/assets/state.js";
test("legacy empty PHP arrays become serializable setting maps", () => {
  const [entry] = normalizeElements([{ id: "text", changes: [] }]);
  entry.changes.desktop = { "font-size": "42px" };
  assert.equal(
    JSON.parse(JSON.stringify(entry)).changes.desktop["font-size"],
    "42px",
  );
  const [mode] = normalizeElements([{ changes: { desktop: [] } }]);
  mode.changes.desktop.translateX = "1px";
  assert.equal(
    JSON.parse(JSON.stringify(mode)).changes.desktop.translateX,
    "1px",
  );
});

test("asset appearance values are typed and reject CSS injection", () => {
  for (const [property, value] of [
    ["background-size", "cover"],
    ["background-position", "25% 70%"],
    ["imageZoom", "140"],
    ["overlay-color", "#12345633"],
    ["box-shadow", "0px 8px 20px 0px #12345633"],
    ["filter", "blur(4px)"],
  ])
    assert.equal(validValue(property, value), true, property);
  for (const [property, value] of [
    ["background-size", "url(https://x)"],
    ["background-position", "50% 50%; color:red"],
    ["imageZoom", "999"],
    ["box-shadow", "0px 0px 20px 0px #12345633;display:none"],
    ["filter", "url(#filter)"],
  ])
    assert.equal(validValue(property, value), false, property);
});
