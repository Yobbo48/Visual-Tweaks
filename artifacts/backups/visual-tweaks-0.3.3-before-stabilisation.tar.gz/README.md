# Visual Tweaks — 0.3.3 — navigation et retouches intuitives

Plugin WordPress autonome pour retoucher un site PHP/HTML/CSS/JavaScript depuis son rendu réel. JavaScript natif, aucun framework, aucun page builder, aucun service IA. Aucun fichier du thème n’est réécrit.

## Installation

Prérequis : WordPress 6.5+, PHP 8.1+, navigateur moderne prenant en charge les modules ES, Shadow DOM, `ResizeObserver`, `structuredClone` et la propriété CSS individuelle `translate`. Validation effectuée avec PHP 8.5.10 et Chromium / WebKit / Firefox (syntaxe PHP également vérifiée sous 8.3) ; la compatibilité avec les autres configurations reste à vérifier.

1. Dans WordPress : **Extensions → Ajouter une extension → Téléverser**, choisir `artifacts/visual-tweaks-0.3.3.zip`, puis activer.
2. Alternativement, copier uniquement le dossier `visual-tweaks/` dans `wp-content/plugins/` et activer l’extension.
3. Vérifier **Réglages → Visual Tweaks**. Le système est activé par défaut seulement si `WP_ENVIRONMENT_TYPE` vaut `local` ou `development`. Sans cette constante, WordPress se considère en production : activation explicite nécessaire.
4. Se connecter avec un compte possédant `manage_options`, afficher une page du site, puis cliquer **Édition visuelle** dans la barre WordPress.

Le thème doit appeler `wp_head()`, `wp_footer()` et permettre l’affichage de la barre d’administration. Aucun changement à vos sites existants n’est nécessaire pour tester ce projet.

## Banc d’essai autonome

Le dossier `dev/fixture-theme/` est un petit thème de test, avec un téléphone tourné, une translation déjà présente, des media queries et une image de médiathèque. La base et les uploads sont stockés dans `.local/`, séparément de vos autres projets. Rien n’est déployé.

Avec Node.js 24.18+ et npm :

```sh
npm install
npx playwright install chromium firefox webkit
npm run dev
```

Ouvrir **http://127.0.0.1:9410/**. Connexion de test : `vt-admin` / `vt-local-only-9410`. Compte abonné de test : `vt-subscriber`, même mot de passe. Ces comptes sont réservés à ce banc local. Le serveur utilise WordPress Playground, WordPress 7.1.2 demandé, PHP 8.3 et SQLite. La version réellement servie est affichée dans le rapport de vérification quand disponible.

```sh
npm run check
npm test
npm run test:e2e
npm run test:viewport
npm run test:ergonomics
npm run package
```

Vérification de la 0.3.2, le 8 octobre 2026 : syntaxe PHP/JS valide, 13 tests unitaires et 108 vérifications de parcours réussies sur **WordPress 7.1.3 réellement servi**, PHP 8.5.10, SQLite, Chromium, WebKit et Firefox (66 parcours hérités sous Chromium, 33 contrôles du canvas et 9 contrôles du thème réel sur les trois moteurs). Résultats dans `artifacts/test-report.json`, `artifacts/ux-test-report.json`, `artifacts/save-test-report.json`, `artifacts/foundations-test-report.json` et `artifacts/width-test-report.json`, captures desktop/mobile dans `artifacts/`.

Pour utiliser un outillage déjà installé sans l’intégrer au projet : `VT_TOOLCHAIN=/chemin/projet` pour les scripts PHP/Playground, `VT_BROWSER_TOOLCHAIN=/chemin/projet` pour Playwright, `VT_CHROMIUM_PATH=/chemin/chromium` si nécessaire. Ce sont des chemins d’outillage de développement ; le ZIP du plugin n’a aucune dépendance Node.

Validation de la **0.3.3** : **13 tests unitaires et 174 contrôles de parcours réussis**, dont 63 contrôles d’ergonomie sur Chromium/WebKit/Firefox, 33 contrôles du canvas, 66 parcours hérités et 12 contrôles du thème réel isolé. Syntaxe PHP/JS valide ; les 191 fichiers du thème source sont inchangés. Détail : `artifacts/validation-0.3.3.json`.

## Ergonomie 0.3.3

**Navigation à gauche**, **canvas au centre**, **propriétés à droite**. La navigation de 276 px se replie complètement avec **Navigation** ou × et contient uniquement **Structure / Assets**. Les propriétés s’ouvrent à la sélection, peuvent être masquées avec **Réglages** et disparaissent à la désélection. Les actions de page (sauvegarde, retour à la sauvegarde, export, reset) restent accessibles indépendamment des panneaux. Les messages occupent une bande stable pour ne pas déplacer les cibles lors d’une retouche. Le viewport logique du site reste indépendant des deux panneaux.

**Structure** partage la sélection DOM du canvas et des propriétés. Les parents s’ouvrent automatiquement ; la ligne active est amenée dans la zone visible avec le minimum de scroll nécessaire. Déplier un autre groupe et sélectionner à nouveau une ligne visible ne ramène pas la liste en haut. Survol, sélection, ascendants et éléments masqués sont distingués ; les types restent simples et les noms/id/classes sont secondaires. Les fonds de conteneurs n’empêchent plus de découvrir leurs enfants. La vue conserve son ouverture et son scroll dans la session, sans toucher au document d’overrides.

**Assets** inventorie les images HTML (dont les images actives de `picture/source`), les URL des fonds CSS résolus, chaque couche à URL, les SVG racines et les fonds des décors `::before` / `::after` effectivement générés. Aucun arrêt arbitraire à 200 visuels ou six niveaux. Les fichiers répétés sont regroupés avec leur nombre d’utilisations ; déplier pour choisir l’occurrence exacte. Chaque ligne indique sa zone, ses dimensions logiques, les actions de sélection/remplacement compatibles et sa source dans **Avancé**. Les miniatures SVG ne copient que des primitives autorisées ; les références `<use>` internes sont résolues avec une profondeur bornée, jamais les ressources externes, scripts ou `foreignObject`.

Sélectionner un asset fait défiler la page, active son cadre, ouvre ses propriétés et synchronise Structure. Un décor de pseudo-élément sélectionne son bloc propriétaire, avec une information explicite : **son remplacement individuel reste réservé au thème**. Les fonds multicouches restent inventoriés mais leur remplacement est refusé pour préserver la composition. **Actualiser** réanalyse les éléments ajoutés ou chargés dynamiquement. Les dimensions des décors sont celles du bloc propriétaire ; elles ne prétendent pas mesurer séparément la boîte du pseudo-élément.

**Aligner l’élément** et **Aligner le contenu** sont séparés. Le bouton rapide **Centrer** et les directions de la toolbar inspectent le contexte : marges automatiques en flux classique, alignement dans la cellule grid, axe transversal flex ou marges automatiques pour un élément seul sur l’axe principal ; disposition des enfants flex/grid ou alignement du texte pour le contenu. Aucun centrage n’utilise `translate`. **Déplacer** reste une finition locale indépendante.

Dans le flux classique, centrer une image en ligne lui ajoute seulement `display: block`. Un bouton/lien en ligne reçoit également `width: fit-content` pour garder une largeur adaptée à son contenu. Ce sont des overrides explicites issus de la commande, annulables et réinitialisables ; aucune largeur mesurée n’est ajoutée automatiquement. Le contrat PHP/JS autorise désormais **uniquement** `display: block`, `width: fit-content` et les valeurs d’alignement énumérées nécessaires. Il n’accepte toujours pas de CSS libre. Les blocs absolus/fixes, l’axe principal d’un groupe flex à plusieurs enfants, les éléments qui remplissent tout l’espace et le centrage vertical en flux classique reçoivent une explication plutôt qu’une mutation sans effet. Aucune section n’est convertie arbitrairement en flex. Le raccourci **Centrer le texte** aligne le contenu d’un texte en bloc ; un texte en ligne sans cadre reçoit une explication demandant de choisir son bloc parent, y compris depuis les réglages typographiques.

**Espacement** distingue espace extérieur, intérieur et entre éléments (ce dernier uniquement pour flex/grid). Les côtés liés sont validés et appliqués ensemble, en une étape d’historique. Marges négatives et zéro sont acceptés ; espaces intérieurs et gap négatifs sont refusés. Les valeurs du thème restent des indications et ne deviennent jamais des overrides par sélection, ouverture de panneau ou changement d’écran.

**Réinitialiser Position / Espacement / Alignement** supprime les propriétés correspondantes dans le mode actif ; les modes supérieurs reprennent la main par héritage. Le reset d’alignement retire aussi les paires de marges automatiques/zéro, les marges de l’axe transversal flex et l’adaptation de bouton utilisées par ces commandes, tout en conservant une marge numérique isolée ; ces marges sont les mêmes propriétés que l’espace extérieur, pas une deuxième couche cachée. Les autres dimensions, couleurs et décalages restent conservés. Le reset complet de l’élément reste disponible.

`npm run test:ergonomics` exécute les parcours sur Chromium, WebKit et Firefox : sélection bidirectionnelle, arbre profond/scroll, assets et miniatures, géométrie réelle des alignements, explications des commandes impossibles, espacement lié/individuel, historique, desktop/tablette/mobile, sauvegarde/refresh et frontend anonyme. Il couvre aussi le double-clic sur un texte lorsque l’ouverture des propriétés modifie le zoom visuel. Rapports et captures : `artifacts/ergonomics-<moteur>-report.json` et `.png`. Sauvegarde préalable : `artifacts/backups/visual-tweaks-0.3.2-before-navigation-alignment.tar.gz`.

## Canvas logique 0.3.2

L’iframe possède son propre viewport CSS : **1440 px** par défaut, **820 px** sur tablette, **390 px** sur mobile. Sa hauteur logique suit `window.innerHeight` du navigateur ; elle n’est pas réduite par les commandes de Visual Tweaks. La sidebar, la toolbar et le redimensionnement de la fenêtre changent seulement le zoom affiché. **Adapter** réduit visuellement le canvas pour qu’il tienne dans la zone disponible ; **100 %** garde son échelle réelle et permet de faire défiler le canvas horizontalement. Le zoom ne devient jamais un override du site. Sous WebKit, certains événements pointer sont quantifiés au pixel écran : les tests de drag vérifient le déplacement logique correspondant aux événements réellement reçus (traces dans les rapports), plutôt que d’exiger une fraction de pixel écran que le moteur n’a pas émise. Les flèches clavier restent exactement à 1 / 10 pixels CSS.

Les presets Desktop proposent 1280 / 1440 / 1600 / 1920 px, une largeur personnalisée et **Fenêtre actuelle**, capturée avant la création de l’interface (`document.documentElement.clientWidth`). La valeur par défaut est configurable dans **Réglages → Visual Tweaks**. Le choix temporaire dans l’éditeur ne modifie pas les retouches de la page. Le mode actif détermine le groupe d’overrides ; le zoom affiché ne décide jamais d’un breakpoint.

`assets/viewport.js` centralise les dimensions, le fit, la conversion des points et les diagnostics. Les événements provenant de l’iframe sont déjà exprimés en pixels CSS logiques ; ceux des poignées dans l’interface sont convertis en divisant par le zoom. Les transformations existantes des éléments restent prises en compte par `geometry.js`. Les outlines, poignées et toolbar utilisent la conversion inverse. Le point focal du panneau demeure dans les coordonnées du panneau, et le cadrage direct dans celles de l’iframe. Les flèches restent à 1 / 10 pixels CSS.

Le canvas `vt-frame=1` conserve l’authentification, mais WordPress ne lui ajoute plus sa barre d’administration, la classe `admin-bar` ou le décalage HTML associé. La sécurité REST, les nonces, les capabilities, les brouillons et la sauvegarde atomique sont conservés. Une preview authentifiée peut encore différer du contenu anonyme si un thème/plugin affiche du contenu spécifique à l’utilisateur, bloque les iframes ou utilise une logique spéciale en iframe. L’éditeur ne réécrit pas ces conditions.

**Comparer le rendu** affiche temporairement le viewport logique, les largeurs internes/client, le zoom, les media queries inspectables et les boîtes logique/affichée de la sélection. Les stylesheets cross-origin ne sont pas inspectables. Les mesures attendent le chargement des polices avant les comparaisons de tests ; les cadres sont actualisés après `document.fonts.ready`. **Réinitialiser ce réglage** enlève uniquement la propriété explicite du mode actif ; **Réinitialiser les réglages de cet écran** enlève le groupe courant, en laissant son héritage ; **Réinitialiser cet élément** retire toutes ses retouches et son contenu remplacé. Aucun ancien CSS n’est reconstruit.

La suite légère `npm run test:viewport` vérifie Chromium, WebKit et Firefox : navigation complète à 1440 malgré une zone disponible inférieure à 1200, géométrie 400/100, fit/100 %, coordonnées, nudge, drag, resize, cadrage, responsive, sauvegarde/refresh, rendu anonyme, transformations et resets. Rapports et captures : `artifacts/viewport-<moteur>-report.json` et `.png`.

Un second WordPress local sur **9411** contient une copie isolée du thème PHP réel **Kevin Legros**, avec ses assets et ses polices locales. Les sources du projet existant ne sont pas modifiées. Pour reproduire ce contrôle avec votre thème, copier un thème de confiance dans `.local/real-theme/kevin-legros/`, adapter le nom dans `dev/real-theme-blueprint.json` et le montage de `dev/real-theme-server.mjs`, puis lancer `npm run dev:real-theme` et `npm run test:real-theme`. Base/uploads séparés ; aucun déploiement. La version de **L’Énergie des Runes** des captures ne dispose pas de staging accessible et n’a pas été modifiée ni validée en production. Les rapports du thème réel isolé sont `artifacts/real-theme-<moteur>-report.json`.

## Correctif 0.3.1 : contrat des dimensions

Rejet reproduit sous WordPress : la poignée d’une zone en `content-box` fractionnaire envoyait `"width": "167.10899999999998px"` (chaîne, desktop), refusé en HTTP 400 par `Schema::value` qui limite les longueurs à quatre décimales. Le chemin de redimensionnement contournait le validateur des champs et soustrayait une largeur CSS fractionnaire d’un `offsetWidth` arrondi. Le payload, les mesures et la règle sont conservés dans `artifacts/width-before-fix.json`. Ce scénario démontre un défaut de la 0.3.0 ; le brouillon du site signalé par l’utilisateur n’a pas fourni sa largeur exacte.

Les dimensions des gestes sont maintenant mesurées avec le modèle de boîte CSS (bordures et espaces intérieurs), normalisées puis validées ensemble avant d’entrer dans les overrides. Le serveur conserve sa liste blanche : aucun CSS arbitraire n’est accepté. Les champs acceptent px, %, rem, em, vw, vh, zéro ; `auto` pour largeur/hauteur/marges et `none` seulement pour largeur maximale. Les nombres sans unité saisis explicitement deviennent des pixels, les décimales sont arrondies à quatre chiffres. Vider un champ supprime sa retouche.

Les valeurs calculées du thème restent des indications dans les champs. Sélectionner, ouvrir un panneau ou changer de breakpoint ne les persiste jamais. Les largeurs `fit-content`, `max-content`, `min-content`, `calc(...)` et `clamp(...)` du thème restent intactes quand on change seulement une couleur ou une position ; elles ne sont jamais copiées automatiquement. À partir de la 0.3.3, le mot-clé contrôlé `fit-content` est aussi autorisé comme override explicite pour l’adaptation d’un bouton lors du centrage ; les expressions CSS libres restent refusées.

Une longueur numérique déjà présente dans un ancien brouillon est normalisée lors de sa récupération, sans inventer de propriété supplémentaire. Une valeur irrécupérable (`NaNpx`, objet au lieu d’une chaîne, etc.) est conservée : la sauvegarde indique l’élément, la propriété et le breakpoint à corriger. Aucune propriété invalide n’est supprimée silencieusement et aucun document partiel n’est sauvegardé.

`tests/width-e2e.mjs` vérifie les payloads REST réels, la validation PHP/JavaScript, les vues desktop/tablette/mobile, l’historique, le rendu public, les rafraîchissements et les anciens brouillons. Le rapport est `artifacts/width-test-report.json`.

## Utilisation

- **Cliquez sur un élément** : ses actions principales apparaissent à côté. La navigation à gauche sert à retrouver un élément ; le panneau **Réglages** à droite, visible uniquement à la sélection et repliable, propose Contenu, Taille et position, Espacement, Style, Texte et Responsive. Les informations techniques restent dans **Réglages avancés**.
- **Modifier un texte** : double-cliquer ou choisir **Modifier**, puis écrire dans la page. **Terminer** valide l’édition ; Échap annule cette session de texte et de style. Gras, italique, police, taille, couleur et alignement sont accessibles dans la barre contextuelle. Une session forme une seule étape d’historique.
- Le texte reste du texte brut, y compris au collage : aucun HTML n’est exécuté. Seuls les éléments feuilles sans enfants HTML sont modifiables. Les styles s’appliquent à l’élément entier, pas à une sélection de mots. Le lien d’un élément `<a>` existant est modifiable avec une adresse autorisée ; aucun lien imbriqué n’est créé.
- **Déplacer** : glisser un asset déjà sélectionné, ou la poignée de déplacement. Les flèches du clavier déplacent de 1 px, Maj + flèche de 10 px ; elles restent inactives dans les champs et la saisie inline. La barre **Déplacer** propose quatre boutons et un pas de 1/5/10 px. Les frappes rapprochées forment une étape d’historique, clôturée après 550 ms sans déplacement. Les décalages s’ajoutent au thème sans imposer de position absolue. Les transformations 2D des parents sont prises en compte ; les effets 3D sont refusés pour les gestes directs. Le glissement nécessite des décalages en px.
- **Redimensionner** : glisser une poignée de coin. Les images gardent leurs proportions ; Shift libère le ratio, également réglable dans le panneau. Le coin opposé reste ancré pour les transformations 2D. Échap annule un geste en cours. Des champs permettent toujours de saisir une valeur exacte ; un nombre seul devient une valeur en pixels.
- **Espacement** : représentation des quatre côtés pour l’espace extérieur et intérieur, avec possibilité de lier les valeurs. Alignement et espace entre éléments apparaissent pour les groupes compatibles.
- **Assets** : inventaire des images, images adaptatives (`picture`/`source` ciblent leur `img`), logos, SVG racines et fonds CSS. Miniature, nom, zone et dimensions ; source dans **Avancé**. **Sélectionner** fait défiler la page et ouvre les réglages, y compris pour un asset recouvert. **Actualiser** réanalyse les éléments chargés dynamiquement. Un élément masqué reste sélectionnable, avec un avertissement sur son absence de cadre visible.
- **Structure** : arborescence de sélection légère, sans déplacement du DOM. **Alt/Cmd + clic** propose les éléments empilés sous le pointeur.
- **Images** : **Remplacer** ouvre la médiathèque WordPress. **Recadrer** permet de glisser l’image dans son cadre ; un point de positionnement et les choix Remplir / Image entière / Étirer restent disponibles. Le cadrage devient visible quand l’image déborde de son cadre ; le fichier original reste intact. Un zoom 100–180 % est disponible pour les fonds CSS et, lorsque le navigateur le prend en charge, les images via `object-view-box`. Une image dans `<picture>` utilise le remplacement unique en neutralisant temporairement ses sources.
- **Apparence** : fond, couleur, bordure, arrondi, opacité, ombres Aucune/Légère/Moyenne/Forte ou personnalisées par champs contrôlés, et flou léger. Les fonds à image unique peuvent recevoir un voile de couleur avec intensité.
- **Fonds CSS** : remplacement par médiathèque, Couvrir / Contenir / Taille réelle, point focal et glissement dans le cadre. La zone et ses enfants restent en place. Les fonds à plusieurs couches sont inventoriés et sélectionnables mais leur remplacement est volontairement refusé.
- **Couleurs** : sélecteur natif, hex, couleurs détectées sur la page, couleurs récentes et personnelles. Les favoris sont locaux au navigateur et au compte ; ils ne constituent pas encore des styles globaux WordPress.
- **Polices** : polices détectées sur le site et quelques familles système, présentées dans leur police. Aucune police externe n’est chargée. Taille, graisse, italique, interligne, espacement et casse restent personnalisables.
- **Desktop / Tablet / Mobile** : boutons visuels en haut. Un point indique des exceptions tablette/mobile ; les champs personnalisés portent un indicateur. Une valeur vide retrouve l’héritage.
- **Enregistrer** affiche clairement **Modifications non enregistrées**, puis **Enregistré**. Un geste correspond à une étape d’historique ; les favoris de couleurs ne font pas partie des retouches de la page.
- **Annuler/Rétablir** : boutons, Cmd/Ctrl+Z, Cmd/Ctrl+Shift+Z. Dans un champ, ces raccourcis restent ceux du navigateur. Cmd/Ctrl+S enregistre. Échap désélectionne.
- **Enregistrer** écrit tout le brouillon de cette page en une seule opération atomique. Une retouche affiche immédiatement son résultat, mais reste un brouillon jusqu’à l’enregistrement. Les retouches faites pendant une requête de sauvegarde restent à enregistrer.
- **Réinitialiser cet élément** / **Réinitialiser la page** enlèvent les overrides dans le brouillon ; enregistrer pour persister le reset. L’historique reste disponible pendant la session, y compris après sauvegarde.
- **Revenir à la sauvegarde** restaure le dernier état enregistré ; ce retour est lui-même annulable.
- **Exporter le brouillon JSON** fournit les cibles, empreintes, breakpoints et propriétés. Il prépare la future intégration au thème avec Codex, sans appeler d’IA.

Un brouillon est conservé dans `localStorage`, isolé par origine, compte et page. Après rechargement, **Récupérer le brouillon local** le rétablit explicitement. Une version ancienne reste exportable mais ne peut pas écraser une version plus récente. Si le stockage local échoue, un message le signale ; quitter avec des retouches déclenche un avertissement. Les brouillons peuvent contenir le texte de votre page : les supprimer via le navigateur si nécessaire.

## Responsive centralisé

L’éditeur affiche la même page WordPress dans une iframe de même origine, avec ses vrais scripts et media queries. Le canvas est zoomé autour de l’iframe ; sa taille affichée ne modifie pas le viewport CSS. Il ne simule pas le mobile en réduisant simplement un conteneur.

| Mode | Aperçu | Application des overrides |
| --- | --- | --- |
| Desktop | viewport logique 1440 px par défaut, configurable | base commune à toutes les largeurs |
| Tablet | 820 px | exceptions à `max-width: 1023px` |
| Mobile | 390 px | exceptions à `max-width: 767px` |

Une valeur vide enlève l’exception du mode courant. Mobile hérite de Tablet puis de Desktop ; sans override, le CSS du thème s’applique. Les décalages X/Y héritent indépendamment. Le moteur produit au maximum deux media queries pour toute la page. Ces seuils sont fixes dans ce MVP ; adapter ultérieurement les constantes centralisées PHP/JS si votre thème utilise d’autres seuils.

## Identification des cibles

Ordre de préférence :

1. `data-vt-id="hero-phone"`, unique dans la page, alphabet `A-Z a-z 0-9 _ -`.
2. `id` unique compatible avec un sélecteur simple.
3. Balise + une à trois classes stables si cette combinaison est unique.
4. Chemin court, limité à cinq niveaux, éventuellement ancré sur un id et utilisant `nth-of-type` seulement si nécessaire. Refus si aucune cible unique n’est trouvée.

Les classes d’état (`is-*`, `has-*`, active, focus, hover…) ne servent pas d’ancrage. Chaque cible conserve une empreinte : balise, classes stables, identifiant s’il existe, texte d’origine pour les feuilles, src d’origine pour les images. Le runtime exige un seul résultat et une empreinte compatible ; une cible absente ou modifiée est ignorée et signalée dans l’éditeur. Il ne cherche pas un élément « ressemblant » ailleurs.

Sur un thème que vous contrôlez, `data-vt-id` est recommandé. Les sélecteurs CSS et empreintes ne peuvent pas garantir l’identité d’un composant après une réécriture du DOM : deux blocs strictement identiques sont notamment difficiles à distinguer. Changer le texte/src original ou les classes peut rendre un override inapplicable ; exportez les données puis réidentifiez l’élément. Pas de sélection dans les iframes tierces, Shadow DOM du site, pseudo-éléments ou paths SVG individuels. Le clic sur un path sélectionne son SVG racine. Les éléments apparus après l’initialisation peuvent être inventoriés avec **Actualiser**, mais les overrides ne sont pas continuellement réappliqués après chaque reconstruction du DOM. `data-vt-ignore` exclut une zone de la sélection.

## Architecture

```text
visual-tweaks/
  visual-tweaks.php             bootstrap WordPress
  includes/class-plugin.php    accès, barre admin, REST, réglages, chargement
  includes/class-schema.php    schéma, validation stricte, assets WordPress
  includes/class-store.php     stockage par page, compare-and-swap atomique
  assets/runtime.js            résolution, application/restauration des overrides
  assets/selection.js          identification, empreintes, picture et SVG racine
  assets/assets.js             découverte des visuels, arbre DOM et miniatures SVG sûres
  assets/navigation.js        vues Structure/Assets, expansion et scroll ; sélection fournie par l’éditeur
  assets/alignment.js         commandes sémantiques et groupes de reset
  assets/state.js              normalisation des cartes de réglages historiques
  assets/styles.js             CSS et héritage responsive centralisés
  assets/history.js            historique immuable et borné
  assets/validation.js         validation des champs avant prévisualisation
  assets/inline-editor.js      saisie directe sécurisée et transaction de texte
  assets/contextual-toolbar.js barre contextuelle et popovers
  assets/appearance-controls.js couleurs et découverte des polices
  assets/geometry.js           déplacement et resize dans les transformations 2D
  assets/viewport.js           viewport logique, fit et conversions de coordonnées
  assets/editor.js             orchestration, panneau, iframe, médiathèque, sauvegarde
  assets/editor.css            interface isolée par Shadow DOM
```

Les options `vt_page_<sha256>` ne sont pas autoloadées. Un document par URL relative contient `schemaVersion`, `page`, `revision`, `elements`, `updatedAt`, `updatedBy`. Les paramètres d’édition et de tracking sont retirés ; les autres paramètres sont triés et conservés, afin de distinguer par exemple `/?etude=...`. Limites : 200 cibles/page, 300 Ko/requête, 80 snapshots d’historique en mémoire.

```json
{
  "schemaVersion": 1,
  "page": "/",
  "revision": 3,
  "elements": [{
    "id": "hero-phone",
    "selector": "[data-vt-id=\"hero-phone\"]",
    "strategy": "data",
    "fingerprint": {"tag": "img", "classes": ["hero-phone"], "anchor": "hero-phone", "src": "/phone.png"},
    "changes": {"desktop": {"translateY": "-25px"}, "mobile": {"translateY": "12px"}},
    "content": {"attachmentId": 42}
  }]
}
```

Les URLs d’images sont résolues côté WordPress depuis les IDs de médiathèque. Aucun CSS brut, JavaScript, HTML interprété ou URL d’asset arbitraire n’est accepté par l’API. Les routes GET/PUT exigent `manage_options`, système actif et nonce REST. Un UPDATE conditionnel sur l’ancienne valeur sérialisée protège la sauvegarde ; une insertion unique protège la première sauvegarde concurrente. Conflit HTTP 409 : conserver/exporter le brouillon, recharger la page actuelle, réappliquer les changements souhaités. Il n’y a pas encore de fusion automatique ni de reprise automatique des conflits.

Le runtime ajoute seulement des marqueurs temporaires `data-vt-target` aux cibles vérifiées et une feuille `<style id="vt-generated-styles">` lisible. Aucun attribut `style` persistant n’est ajouté aux éléments du site. L’interface utilise ses propres styles transitoires pour ses cadres et son iframe.

## Visiteurs, performance et arrêt

Les **réglages enregistrés** sont visibles dans le rendu public lorsque le plugin est actif. L’**interface et les brouillons** sont réservés aux administrateurs en mode édition. Aucun script de l’éditeur ni configuration nonce n’est envoyé aux visiteurs. Aucun script Visual Tweaks n’est chargé sur une page sans retouches. Sur une page retouchée, seul le petit runtime et les données nécessaires à cette page sont chargés.

Les prévisualisations administrateur reçoivent des en-têtes `private, no-store` et `DONOTCACHEPAGE`. Le cache/CDN/hébergement doit aussi exclure les sessions connectées et les URLs `vt-edit` / `vt-frame`. Les caches publics déjà remplis doivent être purgés après sauvegarde ; le MVP n’intègre pas d’API de purge propre à chaque fournisseur.

Arrêt complet : désactiver dans **Réglages → Visual Tweaks**, désactiver l’extension, ou définir `VISUAL_TWEAKS_DISABLED` à `true` dans la configuration WordPress. Le runtime, les overrides et l’éditeur cessent alors de s’appliquer. Les données restent conservées pour une réactivation ; désinstaller ne purge pas automatiquement vos retouches.

## Limites et prochaines étapes

- Aucun changement structurel du DOM, PHP, logique métier ou système d’animation. Pas de déplacement entre sections.
- L’inventaire ne traverse pas les shadow roots ni les iframes tiers. Il découvre les URL CSS (y compris `image-set` lorsqu’il contient des `url(...)`), pas les gradients seuls ni les dessins canvas. Les SVG à filtres/masques complexes peuvent avoir une miniature simplifiée ; les sprites externes ne sont pas chargés. Un SVG se retouche mais ne se remplace pas. Pseudo-éléments et fonds multicouches sont inventoriés, sans remplacement destructeur.
- Les gestes directs traitent les transformations 2D et le zoom, mais pas la perspective/3D. Les éléments animés, tailles contraintes par le thème et mises en page complexes demandent des vérifications visuelles. Un redimensionnement impose une largeur/hauteur explicite au breakpoint courant.
- Les overrides gagnent via `!important`. Un style inline du thème lui-même `!important` peut prendre le dessus. Les animations de `translate` et translations 3D ne sont pas traitées ; les transformations `transform` classiques sont conservées.
- Texte/images appliqués côté client : ils ne modifient pas la source PHP/WordPress, le HTML serveur, les métadonnées SEO ou les exports du thème. Un bref affichage du contenu original reste possible avant le runtime.
- L’iframe recharge la page une seconde fois en édition et requiert une politique CSP compatible avec les frames de même origine. La navigation et les formulaires sont bloqués, mais les scripts du thème s’exécutent : cette version vise les pages de développement statiques, pas les applications avec effets métier au chargement.
- Pas de CSS libre (`calc`, `var`, gradient, `url`), pas de système typographique complet, pas de gestion globale des retouches de plusieurs pages, pas d’import JSON ni de journal durable multi-session.
- Compatibilité vérifiée sur WordPress Playground/SQLite, Chromium/WebKit/Firefox, le fixture et une copie locale isolée du thème Kevin Legros. MySQL/MariaDB, autres thèmes/plugins et caches nécessitent leur propre validation ; aucun test ni déploiement en production.

Cette version livre les fondations de sélection et de manipulation avant les effets et les composants. L’API et le schéma version 1 sont conservés ; les retouches précédentes restent utilisables. Sauvegarde préalable : `artifacts/backups/visual-tweaks-0.2.0-before-foundations.tar.gz`.

### Correction de sauvegarde démontrée

Après une sauvegarde de contenu seul, PHP sérialisait `changes` (ou un breakpoint vide) comme `[]`. Le JavaScript y ajoutait des clés qui fonctionnaient en prévisualisation mais que `JSON.stringify()` omettait. La requête réussissait avec HTTP 200 : ces propriétés n’étaient pas dans le payload, ni dans WordPress. Le nonce et le compare-and-swap n’étaient pas responsables de ce défaut.

La réponse PHP conserve maintenant ces groupes comme objets JSON ; l’éditeur normalise aussi les anciennes données et brouillons. Il confirme l’état canonique renvoyé par WordPress et préserve les changements faits pendant la requête. Un échec apparaît au-dessus de la page, même si les réglages sont masqués. Le brouillon reste localement conservé ; un conflit 409 reste explicite et exportable, sans écrasement automatique.

`tests/save-e2e.mjs` reproduit la sauvegarde de texte seul, le refresh, l’ajout de taille et de texte, puis vérifie le payload, la lecture REST, « Enregistré », le refresh, quitter/revenir et le rendu anonyme. Il teste également panne réseau, modification pendant une sauvegarde et conflit. Diagnostic avant correction : `artifacts/save-contract-before-fix.json` ; après : `artifacts/save-contract-diagnostic.json`.

Les fonds enregistrent uniquement un ID de médiathèque contrôlé et un type d’asset, pas du CSS ou du HTML utilisateur. Le runtime génère les styles, vérifie l’empreinte du fond original et résout l’URL côté WordPress.

Prochaines étapes, volontairement non implémentées :

- Étape 2 : presets d’effets respectant `prefers-reduced-motion`, rôles de couleurs/polices facultatifs stockés dans WordPress, seuils responsive configurables.
- Étape 3 : palette **+ Ajouter** et composants possédés par Visual Tweaks. Prévoir des enregistrements typés (`id`, `type`, `content`, `styles`, `animation`, zone d’insertion), des zones explicitement compatibles et un rendu serveur contrôlé. Aucun HTML arbitraire ; duplication/suppression uniquement de ces composants. Ne pas assimiler les overrides actuels à des composants ajoutés.
- Ensuite : composants dynamiques, journal durable, purge de cache extensible et transfert explicite des overrides au thème avec Codex.

Références WordPress utilisées : [routes REST et contrôles de permission](https://developer.wordpress.org/rest-api/extending-the-rest-api/routes-and-endpoints/), [médiathèque native](https://developer.wordpress.org/reference/functions/wp_enqueue_media/).
