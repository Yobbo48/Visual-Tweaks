import test from 'node:test';
import assert from 'node:assert/strict';
import {History} from '../visual-tweaks/assets/history.js';
import {generateCSS,effectiveProperties} from '../visual-tweaks/assets/styles.js';
import {validValue} from '../visual-tweaks/assets/validation.js';
test('undo/redo preserve snapshots and truncate obsolete branches',()=>{
  const history=new History([]); const value=[{id:'phone',x:1}];history.push(value);value[0].x=99;
  assert.deepEqual(history.undo(),[]);assert.deepEqual(history.redo(),[{id:'phone',x:1}]);
  history.undo();history.push([{id:'title'}]);assert.equal(history.canRedo,false);
});
test('controls refuse CSS injection, unsupported values and negative dimensions',()=>{
  for(const value of ['url(javascript:alert(1))','10px;color:red','var(--secret)','calc(100% - 1px)','-20px','20'])assert.equal(validValue('width',value),false);
  assert.equal(validValue('translateY','-25px'),true);assert.equal(validValue('padding-top','-1px'),false);assert.equal(validValue('color','#aabbcc'),true);assert.equal(validValue('object-position','100.01% 50%'),false);
});
test('responsive generation groups exceptions in at most two media queries',()=>{
  const elements=Array.from({length:20},(_,i)=>({id:`phone-${i}`,selector:'.phone',changes:{desktop:{translateX:'20px',translateY:'-25px','max-width':'280px'},tablet:{translateY:'-10px'},mobile:{translateX:'0px','font-size':'16px'}}}));
  const css=generateCSS(elements);
  assert.equal((css.match(/@media/g)||[]).length,2);
  assert.ok(css.includes('calc(var(--vt-base-x, 0px) + 20px) calc(var(--vt-base-y, 0px) + -10px)'));
  assert.ok(css.includes('calc(var(--vt-base-x, 0px) + 0px) calc(var(--vt-base-y, 0px) + -10px)'));
  assert.equal(css.includes('transform:'),false);
  assert.deepEqual(effectiveProperties(elements[0],'mobile'),{translateX:'0px',translateY:'-10px','max-width':'280px','font-size':'16px'});
});
