import {resolve, canEditText} from './selection.js';
import {generateCSS} from './styles.js';

export class Runtime {
  constructor(doc, elements) {
    this.doc = doc; this.elements = elements; this.originals = new Map(); this.targets = new Map(); this.issues = [];
    this.style = doc.createElement('style'); this.style.id = 'vt-generated-styles'; doc.head.append(this.style);
    this.resize = () => this.render(this.elements);
    doc.defaultView.addEventListener('resize', this.resize);
    this.render(elements);
  }
  remember(node) {
    if (this.originals.has(node)) return;
    const attributes = {};
    for (const attr of ['src','srcset','sizes','alt']) attributes[attr] = node.getAttribute(attr);
    this.originals.set(node, {text: node.textContent, attributes});
  }
  restore() {
    this.style.textContent = '';
    for (const [node, original] of this.originals) {
      node.removeAttribute('data-vt-target');
      if (original.textChanged && canEditText(node)) node.textContent = original.text;
      original.textChanged = false;
      if (original.imageChanged && node.localName === 'img') for (const [attr, value] of Object.entries(original.attributes)) {
        if (value === null) node.removeAttribute(attr); else node.setAttribute(attr, value);
      }
      if (node.localName === 'img') for (const source of node.parentElement?.localName === 'picture' ? node.parentElement.querySelectorAll('source') : []) {
        if (source.dataset.vtOriginalSrcset !== undefined) { source.setAttribute('srcset', source.dataset.vtOriginalSrcset); delete source.dataset.vtOriginalSrcset; }
      }
      original.imageChanged = false;
    }
  }
  render(elements) {
    this.restore(); this.elements = structuredClone(elements); this.issues = []; this.targets.clear();
    const bases = new Map(); const valid = [];
    for (const entry of elements) {
      const node = resolve(this.doc, entry, this.originals);
      if (!node) { this.issues.push(entry); continue; }
      this.remember(node);
      const translate = this.doc.defaultView.getComputedStyle(node).translate;
      const parts = translate === 'none' ? ['0px','0px'] : translate.split(' ');
      bases.set(entry.id, [parts[0] || '0px', parts[1] || '0px']);
      node.setAttribute('data-vt-target', entry.id); this.targets.set(entry.id, node); valid.push(entry);
      if (entry.content?.text !== undefined && canEditText(node)) { node.textContent = entry.content.text; this.originals.get(node).textChanged = true; }
      if (entry.content?.image && node.localName === 'img') {
        this.originals.get(node).imageChanged = true;
        for (const source of node.parentElement?.localName === 'picture' ? node.parentElement.querySelectorAll('source') : []) {
          source.dataset.vtOriginalSrcset = source.getAttribute('srcset') || ''; source.removeAttribute('srcset');
        }
        node.removeAttribute('srcset'); node.removeAttribute('sizes');
        node.setAttribute('src', entry.content.image.src); node.setAttribute('alt', entry.content.image.alt || '');
      }
    }
    this.style.textContent = generateCSS(valid, bases);
    return this.issues;
  }
  destroy() { this.restore(); this.style.remove(); this.doc.defaultView.removeEventListener('resize', this.resize); }
}
if (window.VisualTweaksConfig) window.VisualTweaksRuntime = new Runtime(document, window.VisualTweaksConfig.elements);
