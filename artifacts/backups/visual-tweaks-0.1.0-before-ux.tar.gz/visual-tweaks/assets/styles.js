export const BREAKPOINTS = {desktop: 0, tablet: 1023, mobile: 767};
export function declarations(properties, inherited = {}) {
  const lines = [];
  if ('translateX' in properties || 'translateY' in properties) {
    const x = properties.translateX ?? inherited.translateX ?? '0px';
    const y = properties.translateY ?? inherited.translateY ?? '0px';
    lines.push(`  translate: calc(var(--vt-base-x, 0px) + ${x}) calc(var(--vt-base-y, 0px) + ${y}) !important;`);
  }
  for (const [property, value] of Object.entries(properties)) if (!['translateX', 'translateY'].includes(property)) lines.push(`  ${property}: ${value} !important;`);
  return lines.join('\n');
}
export function generateCSS(elements, bases = new Map()) {
  const buckets = {desktop: [], tablet: [], mobile: []};
  for (const entry of elements) {
    const selector = `[data-vt-target="${entry.id}"]`;
    const base = bases.get(entry.id);
    if (base) buckets.desktop.push(`${selector} {\n  --vt-base-x: ${base[0]};\n  --vt-base-y: ${base[1]};\n}`);
    let inherited = {};
    for (const mode of Object.keys(BREAKPOINTS)) {
      const values = entry.changes[mode] || {};
      const body = declarations(values, inherited);
      if (body) buckets[mode].push(`/* ${entry.selector} */\n${selector} {\n${body}\n}`);
      inherited = {...inherited, ...values};
    }
  }
  let css = '/* Visual Tweaks — overrides de cette page */\n' + buckets.desktop.join('\n');
  for (const mode of ['tablet', 'mobile']) if (buckets[mode].length) css += `\n@media (max-width: ${BREAKPOINTS[mode]}px) {\n${buckets[mode].join('\n')}\n}`;
  return css;
}
export function effectiveProperties(entry, mode) {
  let result = {};
  for (const current of Object.keys(BREAKPOINTS)) { result = {...result, ...entry.changes[current]}; if (current === mode) break; }
  return result;
}
