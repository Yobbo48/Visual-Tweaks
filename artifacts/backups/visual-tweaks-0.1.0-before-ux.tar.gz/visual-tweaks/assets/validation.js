const enums = {
  position:['static','relative','sticky'],
  'text-align':['left','center','right','justify','start','end'],
  'align-items':['normal','start','end','center','stretch','baseline'],
  'justify-content':['normal','start','end','center','space-between','space-around','space-evenly'],
  'object-fit':['fill','contain','cover','none','scale-down'],
  visibility:['visible','hidden'],
  'border-style':['none','solid','dashed','dotted']
};
const lengths = new Set(['translateX','translateY','width','height','max-width','min-width','margin-top','margin-right','margin-bottom','margin-left','padding-top','padding-right','padding-bottom','padding-left','gap','font-size','letter-spacing','border-radius','border-width']);
export function validValue(property,value) {
  if(typeof value !== 'string' || value.length > 80) return false;
  if(enums[property]) return enums[property].includes(value);
  if(lengths.has(property)) {
    if(value === 'auto') return property.startsWith('margin-') || ['width','height'].includes(property);
    if(value === 'none') return property === 'max-width';
    const match=value.match(/^(-?(?:\d{1,5}(?:\.\d{1,4})?|\.\d{1,4}))(px|%|rem|em|vw|vh)?$/);
    return !!match && (Number(match[1]) === 0 || !!match[2]) && (Number(match[1]) >= 0 || ['translateX','translateY','letter-spacing'].includes(property) || property.startsWith('margin-'));
  }
  if(['color','background-color','border-color'].includes(property)) return /^(?:#[a-fA-F0-9]{3}|#[a-fA-F0-9]{6}|#[a-fA-F0-9]{8}|transparent|currentColor)$/.test(value);
  if(property === 'opacity') return value.trim() !== '' && Number.isFinite(Number(value)) && Number(value) >= 0 && Number(value) <= 1;
  if(property === 'font-weight') return /^[1-9]00$/.test(value);
  if(property === 'z-index') return value === 'auto' || /^-?\d{1,6}$/.test(value);
  if(property === 'line-height') return /^(?:normal|(?:\d{1,3}(?:\.\d{1,4})?|\.\d{1,4})(?:px|%|rem|em)?)$/.test(value);
  if(property === 'object-position') return /^(?:100|[0-9]{1,2})(?:\.\d{1,2})?% (?:100|[0-9]{1,2})(?:\.\d{1,2})?%$/.test(value) && value.split(' ').every(v=>parseFloat(v) <= 100);
  return false;
}
