import {identify, editable, canEditText} from './selection.js';
import {History} from './history.js';
import {effectiveProperties} from './styles.js';
import {validValue} from './validation.js';

const config = window.VisualTweaksConfig;
if (config?.editor) start();
function start() {
  const host = document.createElement('div'); host.id = 'vt-editor-host'; document.body.append(host);
  const ui = host.attachShadow({mode: 'open'});
  const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = new URL('./editor.css', import.meta.url).href; ui.append(css);
  const shell = document.createElement('div'); shell.className = 'shell';
  shell.innerHTML = `<header><div class="brand"><b>VT</b><span>Visual Tweaks<small>Retouches de cette page</small></span></div><nav aria-label="Aperçu responsive"><button data-mode="desktop">Desktop</button><button data-mode="tablet">Tablet</button><button data-mode="mobile">Mobile</button></nav><span id="state" role="status"></span><button id="undo" title="Cmd/Ctrl + Z">Annuler</button><button id="redo" title="Cmd/Ctrl + Shift + Z">Rétablir</button><button id="save" class="primary">Enregistrer</button><button id="exit">Quitter</button></header><main><div class="stage"><div class="viewport"><iframe title="Page WordPress — aperçu réel"></iframe></div><div class="outline hover"><span></span></div><div class="outline selected"><span></span><button class="drag" title="Glisser pour déplacer" aria-label="Déplacer l’élément">↔</button></div></div><aside><div id="panel"></div><footer><button id="reset-page">Réinitialiser la page</button><button id="export">Exporter le brouillon JSON</button><button id="discard">Revenir à la sauvegarde</button><div id="recovery"></div><p id="message" role="status" aria-live="polite"></p></footer></aside></main>`;
  ui.append(shell);
  const $ = selector => ui.querySelector(selector);
  const frame = $('iframe'), panel = $('#panel'), state = $('#state');
  $('aside').prepend($('#message'));
  let draft = structuredClone(config.elements), saved = JSON.stringify(draft), revision = config.revision;
  const history = new History(draft);
  let selected = null, spec = null, mode = 'desktop', runtime = null, busy = false, pending = null, drag = null;
  const draftKey = `visual-tweaks:${location.origin}:${config.editor.userId}:${config.page}`;
  let recovered = null;
  try { recovered = JSON.parse(localStorage.getItem(draftKey)); } catch {}
  let recoveryPending = !!(recovered && recovered.page === config.page && Array.isArray(recovered.elements) && JSON.stringify(recovered.elements) !== saved);
  const message = (text, error = false) => { $('#message').textContent = text; $('#message').classList.toggle('error', error); };
  const dirty = () => JSON.stringify(draft) !== saved;
  function persistDraft() {
    try {
      if (dirty()) localStorage.setItem(draftKey, JSON.stringify({schemaVersion: 1, page: config.page, revision, elements: draft}));
      else if (!recoveryPending) localStorage.removeItem(draftKey);
    } catch { message('Le brouillon local n’a pas pu être conservé. Enregistrez ou exportez avant de fermer.', true); }
  }
  function status() {
    state.textContent = busy ? 'Enregistrement…' : dirty() ? 'Brouillon non enregistré' : 'Enregistré';
    state.classList.toggle('dirty', dirty());
    $('#undo').disabled = !history.canUndo; $('#redo').disabled = !history.canRedo;
    $('#save').disabled = busy || !dirty() || !runtime;
    $('#reset-page').disabled = busy;
    persistDraft();
  }
  function flush() { clearTimeout(pending); pending = null; history.push(draft); status(); }
  function commit() { clearTimeout(pending); pending = setTimeout(flush, 350); }
  function preview() {
    const issues = runtime?.render(draft) || [];
    if (issues.length) message(`${issues.length} cible(s) introuvable(s) ou modifiée(s). Aucun override appliqué à ces cibles.`, true);
    status(); updateOutline();
  }
  function entry() { return draft.find(e => e.id === spec?.id) || spec; }
  function modify(callback) {
    if (!spec) return;
    if (recoveryPending) { message('Un brouillon local attend votre décision. Récupérez-le ou utilisez « Revenir à la sauvegarde » avant de retoucher.', true); return; }
    let item = draft.find(e => e.id === spec.id);
    if (!item) { item = structuredClone(spec); draft.push(item); }
    callback(item); preview(); if (!drag) commit();
  }
  function setProperty(property, value) {
    if (recoveryPending) { message('Récupérez le brouillon local ou revenez à la sauvegarde avant de retoucher.', true); return; }
    message('');
    modify(item => {
      item.changes[mode] ||= {};
      if (value === '') delete item.changes[mode][property]; else item.changes[mode][property] = value;
    });
  }
  function rectOverlay(box, node) {
    if (!node || !node.isConnected) { box.hidden = true; return; }
    const r = node.getBoundingClientRect(), f = frame.getBoundingClientRect(), stage = $('.stage').getBoundingClientRect();
    box.hidden = r.width === 0 && r.height === 0;
    box.style.left = `${f.left + r.left - stage.left}px`; box.style.top = `${f.top + r.top - stage.top}px`;
    box.style.width = `${r.width}px`; box.style.height = `${r.height}px`;
  }
  function updateOutline() {
    rectOverlay($('.selected'), selected);
    if (!selected) return;
    const rect = selected.getBoundingClientRect();
    const dimensions = $('#dimensions');
    if (dimensions) dimensions.textContent = `${Math.round(rect.width)} × ${Math.round(rect.height)} px · x ${Math.round(rect.x)}, y ${Math.round(rect.y)}`;
  }
  function choose(node) {
    flush();
    if (!node) { selected = null; spec = null; renderPanel(); updateOutline(); return; }
    try {
      const existing = [...runtime.targets].find(([, target]) => target === node);
      spec = existing ? structuredClone(draft.find(e => e.id === existing[0])) : identify(node);
      spec.changes = {}; delete spec.content;
      selected = node; message(spec.strategy === 'hierarchy' ? 'Cible par hiérarchie : data-vt-id est conseillé pour la stabiliser.' : '');
      $('.selected span').textContent = `${node.localName} · ${spec.id}`;
      renderPanel(); updateOutline();
    } catch (error) { message(error.message, true); }
  }
  function group(title) {
    const details = document.createElement('details'); details.open = true;
    const summary = document.createElement('summary'); summary.textContent = title; details.append(summary);
    const fields = document.createElement('div'); fields.className = 'fields'; details.append(fields); panel.append(details); return fields;
  }
  function control(container, property, label, options = {}) {
    const wrap = document.createElement('label'); wrap.className = 'field';
    const title = document.createElement('span'); title.textContent = label; wrap.append(title);
    const current = entry()?.changes[mode]?.[property];
    const effective = effectiveProperties(entry(), mode)[property];
    const computed = frame.contentWindow.getComputedStyle(selected).getPropertyValue(property);
    const inherited = property === 'translateX' || property === 'translateY' ? '0px' : computed.trim();
    let input;
    if (options.choices) {
      input = document.createElement('select');
      for (const [value, name] of [['', `Hériter${effective ? ` (${effective})` : ''}`], ...options.choices.map(v => [v,v])]) {
        const option = document.createElement('option'); option.value = value; option.textContent = name; input.append(option);
      }
    } else {
      input = document.createElement('input'); input.type = 'text'; input.autocomplete = 'off'; input.spellcheck = false;
      input.placeholder = effective ?? inherited; input.title = 'Ex. 25px, 40%, 2rem. Vide : retirer ce réglage.';
    }
    input.value = current ?? ''; input.dataset.property = property;
    input.addEventListener('input', () => {
      const value = input.value.trim();
      const valid = value === '' || validValue(property, value);
      input.setCustomValidity(valid ? '' : 'Valeur CSS invalide ou non prise en charge.');
      input.classList.toggle('invalid', !valid);
      if (valid) setProperty(property, value); else message('Valeur refusée. Utilisez une longueur simple avec unité ou une couleur #hex ; le dernier réglage valide reste appliqué.', true);
    });
    input.addEventListener('change', flush); wrap.append(input); container.append(wrap); return input;
  }
  function renderPanel() {
    panel.replaceChildren();
    if (!selected) {
      const heading = document.createElement('h2'); heading.textContent = 'Sélectionnez un élément';
      const help = document.createElement('p'); help.textContent = 'Survolez la page puis cliquez sur un asset, un texte ou un conteneur. Échap désélectionne. La poignée ↔ déplace l’élément.';
      panel.append(heading, help);
      if (draft.length) {
        const title = document.createElement('h3'); title.textContent = 'Éléments retouchés'; panel.append(title);
        for (const item of draft) {
          const button = document.createElement('button'); button.className = 'target-list'; button.textContent = `${item.id} · ${item.selector}`;
          button.addEventListener('click', () => { const node = runtime.targets.get(item.id); if (node) choose(node); else message('Cible introuvable. Exportez les données avant de réviser son identifiant.', true); }); panel.append(button);
        }
      }
      return;
    }
    const heading = document.createElement('h2'); heading.textContent = selected.localName === 'img' ? 'Image' : canEditText(selected) ? 'Texte' : 'Conteneur'; panel.append(heading);
    const info = document.createElement('div'); info.className = 'info';
    for (const text of [`<${selected.localName}>${selected.id ? ` #${selected.id}` : ''}`, [...selected.classList].join(' '), spec.selector, `Cible : ${spec.strategy} · ${mode}`]) {
      const line = document.createElement('code'); line.textContent = text; info.append(line);
    }
    const dimensions = document.createElement('span'); dimensions.id = 'dimensions'; info.append(dimensions); panel.append(info);
    const reset = document.createElement('button'); reset.textContent = 'Réinitialiser cet élément'; reset.id = 'reset-element';
    reset.addEventListener('click', () => { if (recoveryPending) { message('Récupérez le brouillon local ou revenez à la sauvegarde avant de réinitialiser.',true); return; } flush(); draft = draft.filter(e => e.id !== spec.id); history.push(draft); preview(); renderPanel(); message('Réinitialisé dans le brouillon. Enregistrez pour conserver ce reset.'); }); panel.append(reset);
    const position = group('Position');
    control(position, 'translateX', 'Translate X'); control(position, 'translateY', 'Translate Y');
    control(position, 'position', 'Position', {choices: ['static','relative','sticky']}); control(position, 'z-index', 'Z-index');
    const sizes = group('Dimensions');
    for (const [prop,label] of [['width','Largeur'],['max-width','Largeur max.'],['height','Hauteur'],['min-width','Largeur min.']]) control(sizes, prop, label);
    const spacing = group('Espacement');
    for (const prefix of ['margin','padding']) {
      const link = document.createElement('label'); link.className = 'link-values';
      const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; link.append(checkbox, document.createTextNode(` Lier les ${prefix}`)); spacing.append(link);
      const inputs = ['top','right','bottom','left'].map((side,index) => control(spacing, `${prefix}-${side}`, `${prefix} ${['haut','droite','bas','gauche'][index]}`));
      for (const input of inputs) input.addEventListener('input', () => {
        if (checkbox.checked && input.checkValidity()) { for (const sibling of inputs) { sibling.value = input.value; setProperty(sibling.dataset.property, input.value.trim()); } }
      });
    }
    const display = frame.contentWindow.getComputedStyle(selected).display;
    if (display.includes('flex') || display.includes('grid')) {
      const alignment = group('Alignement'); control(alignment, 'gap', 'Gap');
      control(alignment, 'align-items', 'Aligner', {choices:['start','end','center','stretch','baseline']});
      control(alignment, 'justify-content', 'Distribuer', {choices:['start','end','center','space-between','space-around','space-evenly']});
    }
    if (selected.localName === 'img') {
      const image = group('Image'); const replace = document.createElement('button'); replace.textContent = 'Choisir dans la médiathèque'; replace.id = 'replace-image'; image.append(replace);
      replace.addEventListener('click', () => {
        if (!window.wp?.media) { message('Médiathèque WordPress indisponible.', true); return; }
        const media = window.wp.media({title:'Remplacer cette image', library:{type:'image'}, button:{text:'Utiliser cette image'}, multiple:false});
        media.on('select', () => { const asset = media.state().get('selection').first().toJSON(); flush(); modify(item => { item.content ||= {}; item.content.attachmentId = asset.id; item.content.image = {src:asset.url, alt:asset.alt || ''}; }); flush(); message('Image remplacée dans le brouillon.'); }); media.open();
      });
      control(image,'object-fit','Object-fit',{choices:['cover','contain','fill','none','scale-down']});
      const objectValue = effectiveProperties(entry(), mode)['object-position'] || frame.contentWindow.getComputedStyle(selected).objectPosition;
      const positions = objectValue.split(' ');
      const axes = [];
      for (const [index,label] of ['Position X (%)','Position Y (%)'].entries()) {
        const wrap = document.createElement('label'); wrap.className = 'field'; wrap.textContent = label;
        const input = document.createElement('input'); input.type='number'; input.dataset.axis=index; input.min='0'; input.max='100'; input.step='1'; input.value = positions[index]?.endsWith('%') ? parseFloat(positions[index]) : 50; axes.push(input); wrap.append(input); image.append(wrap);
        input.addEventListener('input', () => { if (axes.every(a => a.checkValidity() && a.value !== '')) setProperty('object-position', `${axes[0].value}% ${axes[1].value}%`); }); input.addEventListener('change',flush);
      }
      const clear = document.createElement('button'); clear.textContent = 'Hériter de la position image'; clear.addEventListener('click', () => { setProperty('object-position',''); flush(); renderPanel(); }); image.append(clear);
    }
    if (canEditText(selected) || selected.textContent.trim() && selected.localName !== 'img') {
      const typography = group('Typographie');
      for (const [prop,label] of [['font-size','Taille'],['line-height','Interligne'],['letter-spacing','Espacement lettres'],['color','Couleur']]) control(typography,prop,label);
      control(typography,'font-weight','Graisse',{choices:['100','200','300','400','500','600','700','800','900']});
      control(typography,'text-align','Alignement texte',{choices:['start','left','center','right','justify']});
      if (canEditText(selected)) {
        const wrap = document.createElement('label'); wrap.className='text-field'; wrap.textContent='Texte (override, tous les écrans)';
        const input = document.createElement('textarea'); input.value=entry().content?.text ?? selected.textContent; input.maxLength=4000;
        input.addEventListener('input', () => modify(item => { item.content ||= {}; item.content.text = input.value; })); input.addEventListener('change',flush); wrap.append(input); typography.append(wrap);
      }
    }
    const appearance = group('Apparence');
    for (const [prop,label] of [['background-color','Fond (#hex)'],['opacity','Opacité (0–1)'],['border-radius','Rayon'],['border-width','Bordure'],['border-color','Couleur bordure']]) control(appearance,prop,label);
    control(appearance,'border-style','Style bordure',{choices:['none','solid','dashed','dotted']});
    control(appearance,'visibility','Visibilité',{choices:['visible','hidden']});
    const note = document.createElement('p'); note.className='note'; note.textContent='Champ vide = héritage du thème ou du breakpoint supérieur. Desktop sert de base ; Tablet et Mobile ajoutent leurs exceptions. Masquer conserve la place dans la mise en page.'; panel.append(note);
    updateOutline();
  }
  function setMode(value) {
    flush(); mode = value;
    const available = $('.stage').clientWidth - 48;
    const width = {desktop: Math.max(1100, available), tablet:820, mobile:390}[mode];
    frame.style.width = `${width}px`; frame.style.height = '100%';
    for (const button of ui.querySelectorAll('[data-mode]')) { const active = button.dataset.mode === mode; button.classList.toggle('active',active); button.setAttribute('aria-pressed', String(active)); }
    renderPanel(); $('.hover').hidden=true; requestAnimationFrame(updateOutline);
  }
  for (const button of ui.querySelectorAll('[data-mode]')) button.addEventListener('click', () => setMode(button.dataset.mode));
  function undo(redo = false) { flush(); draft = redo ? history.redo() : history.undo(); preview(); if (spec && !selected?.isConnected) choose(null); else renderPanel(); }
  $('#undo').addEventListener('click', () => undo()); $('#redo').addEventListener('click', () => undo(true));
  function keyboard(event) {
    if (event.key === 'Escape') { choose(null); return; }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z' && !event.target.closest?.('input,textarea,select,[contenteditable]')) { event.preventDefault(); undo(event.shiftKey); }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') { event.preventDefault(); save(); }
  }
  document.addEventListener('keydown',keyboard);
  window.addEventListener('beforeunload', event => { if (dirty()) { event.preventDefault(); event.returnValue = ''; } });
  async function save() {
    if (busy || !dirty() || !runtime) return;
    flush(); busy = true; status();
    const payload = structuredClone(draft);
    try {
      const response = await fetch(config.editor.api, {method:'PUT', credentials:'same-origin', headers:{'Content-Type':'application/json','X-WP-Nonce':config.editor.nonce}, body:JSON.stringify({page:config.page,revision,elements:payload})});
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || `Erreur ${response.status}`);
      revision = data.revision;
      // Inputs remain usable while saving: acknowledge only the submitted snapshot.
      saved = JSON.stringify(payload);
      message(dirty() ? 'Sauvegarde effectuée. De nouvelles retouches restent à enregistrer.' : 'Réglages enregistrés dans WordPress.');
    } catch (error) { message(`Sauvegarde impossible : ${error.message} Le brouillon est conservé.`, true); }
    finally { busy=false; status(); }
  }
  $('#save').addEventListener('click',save);
  $('#export').addEventListener('click', () => {
    flush(); const blob = new Blob([JSON.stringify({schemaVersion:1,page:config.page,revision,breakpoints:config.breakpoints,elements:draft},null,2)],{type:'application/json'});
    const url = URL.createObjectURL(blob), a = document.createElement('a'); a.href=url; a.download='visual-tweaks-draft.json'; a.click(); setTimeout(() => URL.revokeObjectURL(url),1000); message('Brouillon exporté.');
  });
  $('#reset-page').addEventListener('click', () => { if (recoveryPending) { message('Récupérez le brouillon local ou revenez à la sauvegarde avant de réinitialiser.',true); return; } if (!confirm('Retirer toutes les retouches de cette page ? Ce reset reste annulable avant et après sauvegarde dans cette session.')) return; flush(); draft=[]; history.push(draft); preview(); choose(null); message('Page réinitialisée dans le brouillon. Enregistrez pour conserver ce reset.'); });
  $('#discard').addEventListener('click', () => { flush(); recoveryPending=false; $('#recovery').replaceChildren(); draft=JSON.parse(saved); history.push(draft); preview(); renderPanel(); message('Retour à la dernière sauvegarde.'); });
  $('#exit').addEventListener('click', () => {
    flush(); if (dirty() && !confirm('Quitter avec des retouches non enregistrées ? Le brouillon local reste disponible sur ce navigateur.')) return;
    const url=new URL(location.href); url.searchParams.delete('vt-edit'); url.searchParams.delete('vt-frame'); location.href=url.href;
  });
  if (recoveryPending) {
    const recovery=$('#recovery'); const restore=document.createElement('button'); restore.textContent='Récupérer le brouillon local'; recovery.append(restore);
    restore.addEventListener('click', () => {
      flush(); recoveryPending=false; draft=structuredClone(recovered.elements); history.push(draft); revision=recovered.revision;
      preview(); renderPanel(); recovery.replaceChildren();
      message(revision !== config.revision ? 'Brouillon récupéré sur une ancienne version. Exportez-le : la sauvegarde sera refusée pour préserver la version actuelle.' : 'Brouillon local récupéré.', revision !== config.revision);
    });
  }
  // Keep WordPress media dialogs above the editor host, outside its isolated styles.
  const mediaStyle=document.createElement('style'); mediaStyle.textContent='.media-modal{z-index:2147483646!important}.media-modal-backdrop{z-index:2147483645!important}'; document.head.append(mediaStyle);
  frame.addEventListener('load', () => {
    try {
      const doc=frame.contentDocument;
      runtime=frame.contentWindow.VisualTweaksRuntime;
      if (!runtime) { message('Le runtime de la page est indisponible. Vérifiez que le thème appelle wp_footer().',true); return; }
      doc.addEventListener('pointermove', event => { if (drag) return; const node=event.target; if (editable(node) && node !== selected) { $('.hover span').textContent=node.localName; rectOverlay($('.hover'),node); } else $('.hover').hidden=true; },true);
      doc.addEventListener('click', event => { event.preventDefault(); event.stopImmediatePropagation(); if (editable(event.target)) choose(event.target); },true);
      doc.addEventListener('submit', event => { event.preventDefault(); event.stopImmediatePropagation(); },true);
      doc.addEventListener('keydown',keyboard,true);
      doc.addEventListener('scroll', () => { $('.hover').hidden=true; updateOutline(); },true);
      doc.defaultView.addEventListener('resize',updateOutline);
      preview(); renderPanel(); message('Prêt. Cliquez sur un élément dans la page.');
    } catch { message('Aperçu inaccessible. Cette page doit autoriser une iframe de même origine.',true); }
  });
  $('.stage').addEventListener('scroll', () => { $('.hover').hidden=true; updateOutline(); });
  $('.drag').addEventListener('pointerdown', event => {
    if (!selected || !spec) return;
    flush(); const values=effectiveProperties(entry(),mode);
    if (![values.translateX || '0px',values.translateY || '0px'].every(v => /^-?[\d.]+(?:px)?$/.test(v))) { message('Pour glisser, définissez d’abord X et Y en px. Les champs conservent les autres unités.',true); return; }
    event.preventDefault(); event.target.setPointerCapture(event.pointerId);
    drag={x:event.clientX,y:event.clientY,baseX:parseFloat(values.translateX)||0,baseY:parseFloat(values.translateY)||0};
  });
  $('.drag').addEventListener('pointermove', event => {
    if (!drag) return; modify(item => { item.changes[mode] ||= {}; item.changes[mode].translateX=`${Math.round(drag.baseX+event.clientX-drag.x)}px`; item.changes[mode].translateY=`${Math.round(drag.baseY+event.clientY-drag.y)}px`; });
  });
  const endDrag=() => { if (drag) { drag=null; flush(); renderPanel(); } };
  $('.drag').addEventListener('pointerup',endDrag); $('.drag').addEventListener('pointercancel',endDrag);
  $('.hover').hidden=true; $('.selected').hidden=true;
  const url=new URL(location.href); url.searchParams.delete('vt-edit'); url.searchParams.set('vt-frame','1'); frame.src=url.href;
  setMode('desktop'); renderPanel(); status();
  css.addEventListener('load', () => setMode(mode));
  window.addEventListener('resize', () => { if (mode === 'desktop') frame.style.width = `${Math.max(1100, $('.stage').clientWidth - 48)}px`; });
}
