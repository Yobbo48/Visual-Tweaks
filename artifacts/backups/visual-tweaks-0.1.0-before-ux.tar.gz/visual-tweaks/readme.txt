=== Visual Tweaks ===
Contributors: visual-tweaks
Tags: development, visual-editor, css
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Retouches visuelles non destructives pour sites WordPress sur mesure.

== Installation ==
Téléverser le ZIP dans Extensions > Ajouter, activer, puis vérifier Réglages > Visual Tweaks.
L'activation est automatique seulement sur les environnements local/development.
Cliquer Édition visuelle dans la barre d'administration sur une page frontend.

== Description ==
JavaScript natif : sélection, translate X/Y et drag, dimensions, margin/padding,
médiathèque, object-position, typographie, desktop/tablet/mobile, sauvegarde atomique,
undo/redo, reset élément/page et export JSON. Aucun fichier du thème n'est modifié.

Les retouches enregistrées sont visibles publiquement ; l'interface et les brouillons
sont réservés aux comptes manage_options. Les routes exigent un nonce REST.
Les textes sont des overrides de feuilles HTML sans enfants. Les contenus ne sont
pas modifiés côté PHP et peuvent brièvement apparaître avant l'application du runtime.
Le thème doit appeler wp_head/wp_footer et autoriser une iframe de même origine.

Breakpoints : Desktop base, Tablet <= 1023px, Mobile <= 767px.
data-vt-id unique recommandé ; les cibles ambiguës ou incompatibles sont ignorées.
Les caches publics existants doivent être purgés après sauvegarde.

Désactiver dans Réglages > Visual Tweaks ou définir VISUAL_TWEAKS_DISABLED=true
retire tous les overrides sans supprimer les données. Désinstaller conserve les données.
Voir le README.md du projet pour architecture, banc d'essai, limites et roadmap.

== Changelog ==
= 0.1.0 =
Premier MVP autonome, sans IA et sans page builder.
