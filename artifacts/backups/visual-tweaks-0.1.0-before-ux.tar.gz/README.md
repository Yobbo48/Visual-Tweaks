# Visual Tweaks — MVP 0.1.0

Plugin WordPress autonome pour retoucher un site PHP/HTML/CSS/JavaScript depuis son rendu réel. JavaScript natif, aucun framework, aucun page builder, aucun service IA. Aucun fichier du thème n’est réécrit.

## Installation

Prérequis : WordPress 6.5+, PHP 8.1+, navigateur moderne prenant en charge les modules ES, Shadow DOM, `structuredClone` et la propriété CSS individuelle `translate`. Validation effectuée avec PHP 8.3 et Chromium ; la compatibilité avec les autres configurations reste à vérifier.

1. Dans WordPress : **Extensions → Ajouter une extension → Téléverser**, choisir `artifacts/visual-tweaks-0.1.0.zip`, puis activer.
2. Alternativement, copier uniquement le dossier `visual-tweaks/` dans `wp-content/plugins/` et activer l’extension.
3. Vérifier **Réglages → Visual Tweaks**. Le système est activé par défaut seulement si `WP_ENVIRONMENT_TYPE` vaut `local` ou `development`. Sans cette constante, WordPress se considère en production : activation explicite nécessaire.
4. Se connecter avec un compte possédant `manage_options`, afficher une page du site, puis cliquer **Édition visuelle** dans la barre WordPress.

Le thème doit appeler `wp_head()`, `wp_footer()` et permettre l’affichage de la barre d’administration. Aucun changement à vos sites existants n’est nécessaire pour tester ce projet.

## Banc d’essai autonome

Le dossier `dev/fixture-theme/` est un petit thème de test, avec un téléphone tourné, une translation déjà présente, des media queries et une image de médiathèque. La base et les uploads sont stockés dans `.local/`, séparément de vos autres projets. Rien n’est déployé.

Avec Node.js 24.18+ et npm :

```sh
npm install
npx playwright install chromium
npm run dev
```

Ouvrir **http://127.0.0.1:9410/**. Connexion de test : `vt-admin` / `vt-local-only-9410`. Compte abonné de test : `vt-subscriber`, même mot de passe. Ces comptes sont réservés à ce banc local. Le serveur utilise WordPress Playground, WordPress 7.1.2 demandé, PHP 8.3 et SQLite. La version réellement servie est affichée dans le rapport de vérification quand disponible.

```sh
npm run check
npm test
npm run test:e2e
npm run package
```

Vérification du 8 octobre 2026 : syntaxe PHP/JS valide, 3 tests unitaires et 19 vérifications de parcours réussies sur **WordPress 7.1.3 réellement servi**, PHP 8.3, SQLite et Chromium. Résultats dans `artifacts/test-report.json`, captures desktop/mobile dans `artifacts/`.

Pour utiliser un outillage déjà installé sans l’intégrer au projet : `VT_TOOLCHAIN=/chemin/projet` pour les scripts PHP/Playground, `VT_BROWSER_TOOLCHAIN=/chemin/projet` pour Playwright, `VT_CHROMIUM_PATH=/chemin/chromium` si nécessaire. Ce sont des chemins d’outillage de développement ; le ZIP du plugin n’a aucune dépendance Node.

## Utilisation

- Survol : cadre et type de balise. Clic : sélection, panneau, tag/classes/id, sélecteur et dimensions. Les interactions et soumissions dans l’aperçu sont bloquées pendant l’édition.
- **Position** : X/Y sont des décalages supplémentaires par rapport au thème. `-25px` remonte donc de 25 px, même si le thème applique déjà une rotation ou une translation. Glisser la poignée **↔** pour déplacer ; cette manipulation exige des valeurs X/Y en px. Un glissement correspond à une étape d’historique.
- **Dimensions** : largeur, hauteur, min-width, max-width. Longueurs simples `px`, `%`, `rem`, `em`, `vw`, `vh` ; `0` sans unité accepté. Certaines propriétés acceptent `auto` ou `none`.
- **Espacement** : marges, paddings ; cases pour lier les quatre côtés. Les contrôles gap/alignement apparaissent pour flex/grid.
- **Image** : médiathèque native, object-fit, object-position X/Y en %, rayon. Une image dans `<picture>` utilise le remplacement unique en neutralisant temporairement ses sources.
- **Typographie/apparence** : taille, interligne, graisse, espacement lettres, alignement, couleurs `#hex`, opacité, bordures et visibilité. `hidden` conserve l’espace occupé.
- Texte modifiable seulement sur des éléments feuilles sans enfants HTML : l’override utilise `textContent`, jamais du HTML. Il s’applique à tous les écrans. Un texte contenant un lien ou une emphase imbriquée n’est pas réécrit.
- **Annuler/Rétablir** : boutons, Cmd/Ctrl+Z, Cmd/Ctrl+Shift+Z. Dans un champ, ces raccourcis restent ceux du navigateur. Cmd/Ctrl+S enregistre. Échap désélectionne.
- **Enregistrer** écrit tout le brouillon de cette page en une seule opération atomique. Une retouche affiche immédiatement son résultat, mais reste un brouillon jusqu’à l’enregistrement. Les retouches faites pendant une requête de sauvegarde restent à enregistrer.
- **Réinitialiser cet élément** / **Réinitialiser la page** enlèvent les overrides dans le brouillon ; enregistrer pour persister le reset. L’historique reste disponible pendant la session, y compris après sauvegarde.
- **Revenir à la sauvegarde** restaure le dernier état enregistré ; ce retour est lui-même annulable.
- **Exporter le brouillon JSON** fournit les cibles, empreintes, breakpoints et propriétés. Il prépare la future intégration au thème avec Codex, sans appeler d’IA.

Un brouillon est conservé dans `localStorage`, isolé par origine, compte et page. Après rechargement, **Récupérer le brouillon local** le rétablit explicitement. Une version ancienne reste exportable mais ne peut pas écraser une version plus récente. Si le stockage local échoue, un message le signale ; quitter avec des retouches déclenche un avertissement. Les brouillons peuvent contenir le texte de votre page : les supprimer via le navigateur si nécessaire.

## Responsive centralisé

L’éditeur affiche la même page WordPress dans une iframe de même origine, avec ses vrais scripts et media queries. Il ne simule pas le mobile en réduisant simplement un conteneur.

| Mode | Aperçu | Application des overrides |
| --- | --- | --- |
| Desktop | largeur disponible, minimum 1100 px | base commune à toutes les largeurs |
| Tablet | 820 px | exceptions à `max-width: 1023px` |
| Mobile | 390 px | exceptions à `max-width: 767px` |

Une valeur vide enlève l’exception du mode courant. Mobile hérite de Tablet puis de Desktop ; sans override, le CSS du thème s’applique. Les décalages X/Y héritent indépendamment. Le moteur produit au maximum deux media queries pour toute la page. Ces seuils sont fixes dans ce MVP ; adapter ultérieurement les constantes centralisées PHP/JS si votre thème utilise d’autres seuils.

## Identification des cibles

Ordre de préférence :

1. `data-vt-id="hero-phone"`, unique dans la page, alphabet `A-Z a-z 0-9 _ -`.
2. `id` unique compatible avec un sélecteur simple.
3. Balise + une à trois classes stables si cette combinaison est unique.
4. Chemin court, limité à cinq niveaux, éventuellement ancré sur un id et utilisant `nth-of-type` seulement si nécessaire. Refus si aucune cible unique n’est trouvée.

Les classes d’état (`is-*`, `has-*`, active, focus, hover…) ne servent pas d’ancrage. Chaque cible conserve une empreinte : balise, classes stables, identifiant s’il existe, texte d’origine pour les feuilles, src d’origine pour les images. Le runtime exige un seul résultat et une empreinte compatible ; une cible absente ou modifiée est ignorée et signalée dans l’éditeur. Il ne cherche pas un élément « ressemblant » ailleurs.

Sur un thème que vous contrôlez, `data-vt-id` est recommandé. Les sélecteurs CSS et empreintes ne peuvent pas garantir l’identité d’un composant après une réécriture du DOM : deux blocs strictement identiques sont notamment difficiles à distinguer. Changer le texte/src original ou les classes peut rendre un override inapplicable ; exportez les données puis réidentifiez l’élément. Pas de sélection dans les iframes tierces, Shadow DOM du site, pseudo-éléments, SVG internes ou DOM créé après l’initialisation. `data-vt-ignore` exclut une zone de la sélection.

## Architecture

```text
visual-tweaks/
  visual-tweaks.php             bootstrap WordPress
  includes/class-plugin.php    accès, barre admin, REST, réglages, chargement
  includes/class-schema.php    schéma, validation stricte, assets WordPress
  includes/class-store.php     stockage par page, compare-and-swap atomique
  assets/runtime.js            résolution, application/restauration des overrides
  assets/selection.js          identification et empreintes
  assets/styles.js             CSS et héritage responsive centralisés
  assets/history.js            historique immuable et borné
  assets/validation.js         validation des champs avant prévisualisation
  assets/editor.js             panneau, iframe, médiathèque, sauvegarde, drag
  assets/editor.css            interface isolée par Shadow DOM
```

Les options `vt_page_<sha256>` ne sont pas autoloadées. Un document par URL relative contient `schemaVersion`, `page`, `revision`, `elements`, `updatedAt`, `updatedBy`. Les paramètres d’édition et de tracking sont retirés ; les autres paramètres sont triés et conservés, afin de distinguer par exemple `/?etude=...`. Limites : 200 cibles/page, 300 Ko/requête, 80 snapshots d’historique en mémoire.

```json
{
  "schemaVersion": 1,
  "page": "/",
  "revision": 3,
  "elements": [{
    "id": "hero-phone",
    "selector": "[data-vt-id=\"hero-phone\"]",
    "strategy": "data",
    "fingerprint": {"tag": "img", "classes": ["hero-phone"], "anchor": "hero-phone", "src": "/phone.png"},
    "changes": {"desktop": {"translateY": "-25px"}, "mobile": {"translateY": "12px"}},
    "content": {"attachmentId": 42}
  }]
}
```

Les URLs d’images sont résolues côté WordPress depuis les IDs de médiathèque. Aucun CSS brut, JavaScript, HTML ou URL d’asset arbitraire n’est accepté par l’API. Les routes GET/PUT exigent `manage_options`, système actif et nonce REST. Un UPDATE conditionnel sur l’ancienne valeur sérialisée protège la sauvegarde ; une insertion unique protège la première sauvegarde concurrente. Conflit HTTP 409 : conserver/exporter le brouillon, recharger la page actuelle, réappliquer les changements souhaités. Il n’y a pas encore de fusion automatique ni de reprise automatique des conflits.

Le runtime ajoute seulement des marqueurs temporaires `data-vt-target` aux cibles vérifiées et une feuille `<style id="vt-generated-styles">` lisible. Aucun attribut `style` persistant n’est ajouté aux éléments du site. L’interface utilise ses propres styles transitoires pour ses cadres et son iframe.

## Visiteurs, performance et arrêt

Les **réglages enregistrés** sont visibles dans le rendu public lorsque le plugin est actif. L’**interface et les brouillons** sont réservés aux administrateurs en mode édition. Aucun script de l’éditeur ni configuration nonce n’est envoyé aux visiteurs. Aucun script Visual Tweaks n’est chargé sur une page sans retouches. Sur une page retouchée, seul le petit runtime et les données nécessaires à cette page sont chargés.

Les prévisualisations administrateur reçoivent des en-têtes `private, no-store` et `DONOTCACHEPAGE`. Le cache/CDN/hébergement doit aussi exclure les sessions connectées et les URLs `vt-edit` / `vt-frame`. Les caches publics déjà remplis doivent être purgés après sauvegarde ; le MVP n’intègre pas d’API de purge propre à chaque fournisseur.

Arrêt complet : désactiver dans **Réglages → Visual Tweaks**, désactiver l’extension, ou définir `VISUAL_TWEAKS_DISABLED` à `true` dans la configuration WordPress. Le runtime, les overrides et l’éditeur cessent alors de s’appliquer. Les données restent conservées pour une réactivation ; désinstaller ne purge pas automatiquement vos retouches.

## Limites et prochaines étapes

- Aucun changement structurel du DOM, PHP, logique métier ou système d’animation. Pas de déplacement entre sections.
- Le drag est réservé aux décalages en px ; les parents transformés/zoomés, éléments animés et mises en page complexes demandent des vérifications visuelles. Redimensionnement direct à ajouter ; largeur/hauteur se règlent déjà par champs.
- Les overrides gagnent via `!important`. Un style inline du thème lui-même `!important` peut prendre le dessus. Les animations de `translate` et translations 3D ne sont pas traitées ; les transformations `transform` classiques sont conservées.
- Texte/images appliqués côté client : ils ne modifient pas la source PHP/WordPress, le HTML serveur, les métadonnées SEO ou les exports du thème. Un bref affichage du contenu original reste possible avant le runtime.
- L’iframe recharge la page une seconde fois en édition et requiert une politique CSP compatible avec les frames de même origine. La navigation et les formulaires sont bloqués, mais les scripts du thème s’exécutent : cette version vise les pages de développement statiques, pas les applications avec effets métier au chargement.
- Pas de CSS libre (`calc`, `var`, gradient, `url`), pas de système typographique complet, pas de gestion globale des retouches de plusieurs pages, pas d’import JSON ni de journal durable multi-session.
- Compatibilité vérifiée sur le banc Playground/SQLite/Chromium fourni. MySQL/MariaDB, autres navigateurs, thèmes réels et plugins de cache doivent faire l’objet d’une vérification avant utilisation sur ces environnements.

Roadmap : seuils responsive configurables, redimensionnement avec contraintes, ancres développeur mieux renseignées, reprise des composants dynamiques, journal de révisions durable, purge de cache extensible, export CSS avec sélecteurs d’origine puis transfert explicite des retouches au thème avec Codex.

Références WordPress utilisées : [routes REST et contrôles de permission](https://developer.wordpress.org/rest-api/extending-the-rest-api/routes-and-endpoints/), [médiathèque native](https://developer.wordpress.org/reference/functions/wp_enqueue_media/).
